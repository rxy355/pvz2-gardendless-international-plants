// Includes the Official Entity Framework 0.1.1 and the released plant behaviors.
const COLLECTION = "gzh.internationalplants";
const plants = ["headbutter", "iceshroom", "kiwibeast", "tigergrass", "ultomato"];

function filesUnder(reader, prefix) {
  return {
    contentDigest: reader.contentDigest,
    listPaths: () => reader.listPaths().filter(path => path.startsWith(prefix)).map(path => path.slice(prefix.length)),
    readBytes: path => reader.readBytes(prefix + path),
    readText: path => reader.readText(prefix + path),
  };
}

function contentReaders(reader) {
  // Read the original manifests to retain entity identities used by existing saves.
  return plants.map(plant => filesUnder(reader, `plants/${plant}/content/`));
}

const entityFramework = (() => {
//#region mods/entities/src/pack-path.js
function normalizeModRelativePath(input, options = {}) {
	const value = String(input || "").trim().replace(/\\/g, "/");
	if (!value) throw new Error(`${options.label || "path"} is required`);
	if (value.startsWith("/") || /^[a-zA-Z]:/.test(value) || value.includes("\0")) throw new Error(`${options.label || "path"} must be relative to the pack root`);
	const parts = value.split("/").filter((part) => part && part !== ".");
	if (parts.some((part) => part === "..")) throw new Error(`${options.label || "path"} cannot contain parent-directory segments`);
	const normalized = parts.join("/");
	if (!normalized) throw new Error(`${options.label || "path"} is required`);
	return normalized;
}
//#endregion
//#region mods/entities/src/entity-content-descriptor.js
var preparedMedia = /* @__PURE__ */ new WeakMap();
var fail$1 = (message) => {
	throw new Error(`Entity content: ${message}`);
};
var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
function freeze$1(value) {
	if (value && typeof value === "object") {
		Object.values(value).forEach(freeze$1);
		Object.freeze(value);
	}
	return value;
}
function localId(value, label) {
	if (typeof value !== "string" || !/^[a-zA-Z][a-zA-Z0-9_.-]*$/.test(value)) fail$1(`${label} must be a local identifier`);
	return value;
}
function path(value, extension) {
	if (typeof value !== "string") fail$1("resource path must be a string");
	const result = normalizeModRelativePath(value, { label: "entity resource path" });
	if (!result.toLowerCase().endsWith(extension)) fail$1(`expected ${extension} resource: ${result}`);
	return result;
}
function bytes(snapshot, name) {
	const value = snapshot.readBytes(name);
	if (!value?.length) fail$1(`missing or empty resource: ${name}`);
	return value;
}
function json(snapshot, name) {
	const text = snapshot.readText(name);
	if (text === null) fail$1(`missing resource: ${name}`);
	const data = JSON.parse(text);
	if (!object(data)) fail$1(`expected JSON object: ${name}`);
	return data;
}
function pngSize(data) {
	if (data.length < 33 || [
		137,
		80,
		78,
		71,
		13,
		10,
		26,
		10
	].some((byte, i) => data[i] !== byte)) fail$1("invalid PNG header");
	const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
	if (view.getUint32(8) !== 13 || view.getUint32(12) !== 1229472850) fail$1("missing PNG IHDR");
	const width = view.getUint32(16), height = view.getUint32(20);
	if (!width || !height) fail$1("invalid PNG dimensions");
	return {
		width,
		height
	};
}
function validateWav(data) {
	const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
	if (data.length < 12 || view.getUint32(0) !== 1380533830 || view.getUint32(8) !== 1463899717 || view.getUint32(4, true) + 8 !== data.length) fail$1("invalid WAV RIFF header");
	let offset = 12, format = false, samples = false;
	while (offset + 8 <= data.length) {
		const kind = view.getUint32(offset), size = view.getUint32(offset + 4, true);
		if (offset + 8 + size > data.length) fail$1("truncated WAV chunk");
		if (kind === 1718449184) format = size >= 16;
		if (kind === 1684108385) samples = size > 0;
		offset += 8 + size + size % 2;
	}
	if (offset !== data.length || !format || !samples) fail$1("missing WAV format or sample data");
}
function validateDragonBones(skeleton, atlas, armatureName, size) {
	if (skeleton.version !== "5.5") fail$1("only DragonBones 5.5 is supported by this adapter");
	const armatures = skeleton.armature?.filter((armature) => armature.name === armatureName);
	if (armatures?.length !== 1) fail$1(`missing or duplicate armature: ${armatureName}`);
	if (atlas.width !== size.width || atlas.height !== size.height || !Array.isArray(atlas.SubTexture) || !atlas.SubTexture.length) fail$1("atlas dimensions or regions do not match PNG");
	const regions = /* @__PURE__ */ new Set();
	for (const region of atlas.SubTexture) {
		if (!region.name || regions.has(region.name)) fail$1("duplicate or unnamed atlas region");
		if (![
			region.x,
			region.y,
			region.width,
			region.height
		].every(Number.isFinite) || region.x < 0 || region.y < 0 || region.width <= 0 || region.height <= 0 || region.x + region.width > size.width || region.y + region.height > size.height) fail$1("atlas region outside PNG");
		regions.add(region.name);
	}
	const armature = armatures[0];
	let displays = 0;
	for (const skin of armature.skin || []) for (const slot of skin.slot || []) for (const display of slot.display || []) {
		if (display.type !== void 0 && display.type !== "image" && display.type !== 0) fail$1("only DragonBones image displays are supported");
		if (!regions.has(display.path || display.name)) fail$1(`display has no atlas region: ${display.path || display.name}`);
		displays++;
	}
	if (!displays || !Array.isArray(armature.animation)) fail$1("armature needs image displays and animations");
	const animations = /* @__PURE__ */ new Map();
	for (const animation of armature.animation) {
		if (!animation.name || animations.has(animation.name)) fail$1("duplicate or unnamed animation");
		animations.set(animation.name, animation);
	}
	return animations;
}
function localized(value, label) {
	if (!object(value) || !Object.keys(value).length || Object.values(value).some((text) => typeof text !== "string" || !text.trim())) fail$1(`${label} needs non-empty localized text`);
	return value;
}
function point(value, label, positive = false) {
	if (!object(value) || ![value.x, value.y].every(Number.isFinite) || positive && (value.x <= 0 || value.y <= 0)) fail$1(`invalid ${label}`);
	return {
		x: value.x,
		y: value.y
	};
}
function almanacData(source, kind) {
	if (source === void 0) return null;
	if (!object(source)) fail$1("almanac must be an object");
	const data = {
		Introduction: localized(source.Introduction, "almanac.Introduction"),
		Chat: localized(source.Chat, "almanac.Chat"),
		Elements: source.Elements === void 0 ? [] : source.Elements,
		Special: source.Special === void 0 ? [] : source.Special,
		DisplayOffset: source.DisplayOffset === void 0 ? {
			x: 0,
			y: 0
		} : point(source.DisplayOffset, "almanac.DisplayOffset")
	};
	if (kind === "plant") data.BriefIntroduction = localized(source.BriefIntroduction, "almanac.BriefIntroduction");
	else data.DisplayScale = source.DisplayScale === void 0 ? {
		x: 1,
		y: 1
	} : point(source.DisplayScale, "almanac.DisplayScale", true);
	if (!Array.isArray(data.Elements) || !Array.isArray(data.Special)) fail$1("almanac Elements and Special must be arrays");
	if (kind === "zombie" && data.Elements.length > 2) fail$1("zombie almanac supports at most two elements");
	data.Elements = data.Elements.map((element) => {
		if (!object(element)) fail$1("invalid almanac element");
		if (kind === "plant") {
			if (![
				"SUNCOST",
				"RECHARGE",
				"TOUGHNESS"
			].includes(element.TYPE)) fail$1("unsupported plant almanac element");
			return { TYPE: element.TYPE };
		}
		if (!["TOUGHNESS", "SPEED"].includes(element.TYPE) || !Number.isFinite(element.PROGRESS) || element.PROGRESS < 0 || element.PROGRESS > 1) fail$1("invalid zombie almanac element");
		return {
			TYPE: element.TYPE,
			SORT: localized(element.SORT, "almanac element SORT"),
			PROGRESS: element.PROGRESS
		};
	});
	data.Special = data.Special.map((entry) => {
		if (!object(entry)) fail$1("invalid almanac Special entry");
		return {
			NAME: localized(entry.NAME, "almanac Special NAME"),
			DESCRIPTION: localized(entry.DESCRIPTION, "almanac Special DESCRIPTION")
		};
	});
	return data;
}
function prepareEntityContent(pack, snapshot) {
	const text = snapshot.readText("content/entities.json");
	if (text === null) return null;
	const namespace = pack?.meta?.uuid;
	if (typeof namespace !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{2,127}$/.test(namespace)) fail$1("package requires a stable namespace");
	if (pack.contentDigest && pack.contentDigest !== snapshot.digest) fail$1("package snapshot digest mismatch");
	const descriptor = JSON.parse(text);
	if (!object(descriptor) || descriptor.formatVersion !== 1 || !Array.isArray(descriptor.resources) || !Array.isArray(descriptor.entities)) fail$1("expected formatVersion 1 with resources and entities arrays");
	const resources = [], media = /* @__PURE__ */ new Map(), animationSets = /* @__PURE__ */ new Map();
	for (const source of descriptor.resources) {
		if (!object(source)) fail$1("resource must be an object");
		const id = localId(source.id, "resource id");
		if (media.has(id)) fail$1(`duplicate resource: ${id}`);
		if (source.kind === "dragonbones") {
			const resource = {
				id,
				kind: source.kind,
				skeleton: path(source.skeleton, ".json"),
				atlas: path(source.atlas, ".json"),
				texture: path(source.texture, ".png"),
				armature: localId(source.armature, "armature")
			};
			const skeleton = json(snapshot, resource.skeleton), atlas = json(snapshot, resource.atlas), image = bytes(snapshot, resource.texture);
			const size = pngSize(image);
			animationSets.set(id, validateDragonBones(skeleton, atlas, resource.armature, size));
			media.set(id, {
				skeleton: freeze$1(skeleton),
				atlas: freeze$1(atlas),
				image,
				...size
			});
			resources.push(resource);
		} else if (source.kind === "audio") {
			const resource = {
				id,
				kind: source.kind,
				path: path(source.path, ".wav")
			};
			const audio = bytes(snapshot, resource.path);
			validateWav(audio);
			media.set(id, { audio });
			resources.push(resource);
		} else fail$1(`unsupported resource kind: ${source.kind}`);
	}
	const identities = /* @__PURE__ */ new Set();
	const entities = descriptor.entities.map((source) => {
		if (!object(source)) fail$1("entity must be an object");
		const id = localId(source.id, "entity id");
		if (identities.has(id)) fail$1(`duplicate entity: ${id}`);
		identities.add(id);
		if (!["plant", "zombie"].includes(source.kind)) fail$1(`unsupported entity kind: ${source.kind}`);
		if (typeof source.behavior !== "string") fail$1("behavior must be a string");
		const parts = source.behavior.split(":");
		if (parts.length === 1) localId(source.behavior, "behavior");
		else {
			const [provider, behavior] = parts;
			if (parts.length !== 2 || !/^[a-zA-Z0-9][a-zA-Z0-9_.-]{2,127}$/.test(provider)) fail$1("invalid behavior provider");
			localId(behavior, "behavior");
			if (provider !== namespace && !(Array.isArray(pack.meta.depends) && pack.meta.depends.includes(provider))) fail$1(`behavior provider requires a direct dependency: ${provider}`);
		}
		const animations = animationSets.get(source.visual);
		if (!animations) fail$1(`entity visual is not a local DragonBones resource: ${source.visual}`);
		for (const name of source.kind === "plant" ? ["Idle", "Death"] : [
			"Idle",
			"Walk",
			"Eat",
			"Death"
		]) if (!animations.has(name)) fail$1(`missing native animation: ${name}`);
		const death = animations.get("Death");
		if (death.playTimes !== 1) fail$1("Death animation must complete once");
		if (source.kind === "zombie" && !death.frame?.some((frame) => frame.event === "die")) fail$1("zombie Death requires a die frame event");
		if (!object(source.feature) || !object(source.properties)) fail$1("entity needs explicit feature and properties objects");
		for (const key of [
			"ID",
			"CODENAME",
			"PROPS",
			"RES",
			"ALMANAC"
		]) if (Object.hasOwn(source.feature, key)) fail$1(`feature.${key} is reserved for native registration`);
		const sounds = source.sounds ?? {};
		if (!object(sounds)) fail$1("sounds must map event names to local audio resources");
		for (const resource of Object.values(sounds)) if (!resources.some((item) => item.id === resource && item.kind === "audio")) fail$1(`sound is not a local audio resource: ${resource}`);
		const almanac = almanacData(source.almanac, source.kind);
		if (source.listed !== void 0 && typeof source.listed !== "boolean") fail$1("listed must be a boolean");
		const listed = source.listed === true;
		if (listed && !almanac) fail$1("listed entities require independent almanac data");
		return {
			almanac,
			listed,
			id,
			key: `${namespace}:${id}`,
			kind: source.kind,
			behavior: source.behavior,
			visual: source.visual,
			feature: source.feature,
			properties: source.properties,
			sounds
		};
	});
	const prepared = freeze$1({
		namespace,
		contentDigest: snapshot.digest,
		formatVersion: 1,
		resources,
		entities
	});
	preparedMedia.set(prepared, media);
	return prepared;
}
/** Private decoder input; copies preserve the validated preparation. */
function readPreparedEntityResource(prepared, id) {
	const value = preparedMedia.get(prepared)?.get(id);
	if (!value) fail$1("resource does not belong to a prepared descriptor");
	return value.audio ? { audio: value.audio.slice() } : {
		...value,
		image: value.image.slice()
	};
}
//#endregion
//#region mods/entities/src/entity-content-assets.js
function abortError() {
	return Object.assign(/* @__PURE__ */ new Error("Entity resource preparation aborted"), { name: "AbortError" });
}
async function decodeEntityContentResources(prepared, { cc, signal, platform = {} }) {
	const instanceToken = crypto.randomUUID();
	const createObjectURL = platform.createObjectURL || ((blob) => URL.createObjectURL(blob));
	const revokeObjectURL = platform.revokeObjectURL || ((url) => URL.revokeObjectURL(url));
	const createImage = platform.createImage || (() => new Image());
	const cleanups = [];
	const resources = /* @__PURE__ */ new Map();
	const consumers = /* @__PURE__ */ new Map();
	let consumerRevision = 0;
	let disposed = false;
	const assertActive = () => {
		if (signal?.aborted) throw abortError();
	};
	const dispose = () => {
		if (disposed) return false;
		if (consumers.size) throw Object.assign(/* @__PURE__ */ new Error("Entity resources still have native consumers"), { code: "ENTITY_RESOURCES_IN_USE" });
		disposed = true;
		resources.clear();
		const errors = [];
		for (const cleanup of cleanups.splice(0).reverse()) try {
			cleanup();
		} catch (error) {
			errors.push(error);
		}
		if (errors.length) throw new AggregateError(errors, "Entity resource cleanup failed");
		return true;
	};
	const own = (asset) => {
		cleanups.push(() => asset.destroy());
		return asset;
	};
	const urlFor = (bytes, type) => {
		const url = createObjectURL(new Blob([bytes], { type }));
		cleanups.push(() => revokeObjectURL(url));
		return url;
	};
	const wait = (promise, releaseLate = () => {}) => new Promise((resolve, reject) => {
		let settled = false;
		const abort = () => {
			if (settled) return;
			settled = true;
			signal?.removeEventListener("abort", abort);
			reject(abortError());
		};
		signal?.addEventListener("abort", abort, { once: true });
		if (signal?.aborted) abort();
		Promise.resolve(promise).then((value) => {
			if (settled) {
				try {
					releaseLate(value);
				} catch (error) {
					console.error("[GP Next:entity-content] Late asset cleanup failed", error);
				}
				return;
			}
			settled = true;
			signal?.removeEventListener("abort", abort);
			resolve(value);
		}, (error) => {
			if (settled) return;
			settled = true;
			signal?.removeEventListener("abort", abort);
			reject(error);
		});
	});
	try {
		assertActive();
		if (!prepared || !Array.isArray(prepared.resources)) throw new Error("Expected prepared entity content");
		for (const resource of prepared.resources) {
			assertActive();
			const data = readPreparedEntityResource(prepared, resource.id);
			if (resource.kind === "dragonbones") {
				if (!cc?.ImageAsset || !cc?.Texture2D || !cc.dragonBones?.DragonBonesAsset || !cc.dragonBones?.DragonBonesAtlasAsset) throw new Error("Full Cocos DragonBones asset module is unavailable");
				const image = createImage();
				const url = urlFor(data.image, "image/png");
				cleanups.push(() => {
					image.src = "";
				});
				image.src = url;
				await wait(image.decode());
				assertActive();
				if (image.naturalWidth !== data.width || image.naturalHeight !== data.height) throw new Error("Decoded PNG dimensions differ from prepared atlas");
				const imageAsset = own(new cc.ImageAsset(image));
				const texture = own(new cc.Texture2D());
				texture.image = imageAsset;
				const atlas = own(new cc.dragonBones.DragonBonesAtlasAsset());
				const skeleton = own(new cc.dragonBones.DragonBonesAsset());
				const cacheName = `gpn:${prepared.namespace}:${resource.id}:${prepared.contentDigest}:${instanceToken}`;
				atlas.atlasJson = JSON.stringify({
					...data.atlas,
					name: cacheName
				});
				atlas.texture = texture;
				skeleton.dragonBonesJson = JSON.stringify({
					...data.skeleton,
					name: cacheName
				});
				resources.set(resource.id, Object.freeze({
					kind: resource.kind,
					armature: resource.armature,
					image: imageAsset,
					texture,
					atlas,
					skeleton
				}));
			} else {
				if (!cc?.AudioClip || !cc.assetManager?.loadRemote || !cc.assetManager?.releaseAsset) throw new Error("Cocos audio asset loader is unavailable");
				const url = urlFor(data.audio, "audio/wav");
				const release = (clip) => {
					if (clip) cc.assetManager.releaseAsset(clip);
				};
				const clip = await wait(new Promise((resolve, reject) => {
					cc.assetManager.loadRemote(url, { ext: ".wav" }, (error, asset) => {
						if (error) {
							try {
								release(asset);
							} catch (cleanupError) {
								reject(new AggregateError([error, cleanupError], "Audio load and cleanup failed"));
								return;
							}
							reject(error);
						} else resolve(asset);
					});
				}), release);
				cleanups.push(() => release(clip));
				assertActive();
				if (!(clip instanceof cc.AudioClip) || !(clip.getDuration() > 0)) throw new Error("WAV did not decode to a non-empty AudioClip");
				resources.set(resource.id, Object.freeze({
					kind: resource.kind,
					clip
				}));
			}
		}
		assertActive();
		return Object.freeze({
			namespace: prepared.namespace,
			contentDigest: prepared.contentDigest,
			get(id) {
				if (disposed) throw new Error("Entity resources are disposed");
				return resources.get(id) || null;
			},
			retain({ entityId, kind, resourceIds }) {
				if (disposed) throw new Error("Entity resources are disposed");
				if (typeof entityId !== "string" || !entityId.startsWith(`${prepared.namespace}:`) || !["native-prefab", "native-icon"].includes(kind) || !Array.isArray(resourceIds) || !resourceIds.length || resourceIds.some((id) => !resources.has(id))) throw new Error("Invalid native resource consumer");
				const key = Symbol();
				consumers.set(key, Object.freeze({
					provider: COLLECTION,
					providerDigest: prepared.contentDigest,
					instanceToken,
					entityId,
					kind,
					resourceIds: Object.freeze([...new Set(resourceIds)])
				}));
				consumerRevision++;
				return () => {
					if (!consumers.delete(key)) return false;
					consumerRevision++;
					return true;
				};
			},
			getConsumers() {
				return Object.freeze({
					domain: "entity-resources",
					complete: false,
					revision: consumerRevision,
					references: Object.freeze([...consumers.values()])
				});
			},
			dispose
		});
	} catch (error) {
		try {
			dispose();
		} catch (cleanupError) {
			throw new AggregateError([error, cleanupError], "Entity resource preparation and cleanup failed");
		}
		throw error;
	}
}
//#endregion
//#region mods/entities/src/entity-native-plan.js
var plain = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var freeze = (value) => {
	if (value && typeof value === "object") {
		Object.values(value).forEach(freeze);
		Object.freeze(value);
	}
	return value;
};
var fail = (code, message) => {
	throw Object.assign(new Error(message), { code });
};
var hex = (text) => [...new TextEncoder().encode(text)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
var codenameFor = (namespace, id) => `gpn_${hex(namespace)}_${hex(id)}`;
function merge(base, override) {
	const result = structuredClone(base);
	for (const [key, value] of Object.entries(override)) {
		if ([
			"__proto__",
			"constructor",
			"prototype"
		].includes(key)) fail("ENTITY_DATA_INVALID", "Unsafe native data key");
		result[key] = plain(value) && plain(result[key]) ? merge(result[key], value) : structuredClone(value);
	}
	return result;
}
function readBaseline(baseline, kind) {
	const isPlant = kind === "plant";
	const rows = baseline[`${kind}Features`]?.[isPlant ? "PLANTS" : "ZOMBIES"];
	const objects = baseline[`${kind}Props`]?.objects;
	const name = isPlant ? "peashooter" : "tutorial";
	if (!Array.isArray(rows) || !rows.length || !Array.isArray(objects)) fail("ENTITY_BASELINE_INVALID", `Missing ${kind} native baseline`);
	const names = /* @__PURE__ */ new Set();
	for (const row of rows) {
		if (!plain(row) || typeof row.CODENAME !== "string" || !row.CODENAME || names.has(row.CODENAME)) fail("ENTITY_BASELINE_INVALID", `Invalid or duplicate ${kind} codename`);
		names.add(row.CODENAME);
	}
	const feature = rows.find((row) => row.CODENAME === name);
	const alias = /^RTID\(([^@()]+)@(PlantProps|ZombieProps)\)$/.exec(feature?.PROPS || "");
	const matches = alias && alias[2] === (isPlant ? "PlantProps" : "ZombieProps") ? objects.filter((item) => item.objclass === (isPlant ? "PlantProperties" : "ZombieProperties") && item.aliases?.includes(alias[1])) : [];
	if (matches.length !== 1 || !plain(matches[0].objdata) || !plain(feature.NAME) || typeof feature.OBTAINWORLD !== "string" || typeof feature.ALMANAC !== "string" || isPlant && (!Array.isArray(feature.TAGS) || !plain(feature.RES)) || !isPlant && typeof feature.RES !== "string") fail("ENTITY_BASELINE_INVALID", `Invalid ${kind} ordinary template`);
	const properties = matches[0].objdata;
	for (const key of isPlant ? [
		"Toughness",
		"SunCost",
		"Cooldown"
	] : [
		"Toughness",
		"WalkSPS",
		"EatDPS"
	]) if (!Number.isFinite(properties[key]) || properties[key] < 0) fail("ENTITY_BASELINE_INVALID", `Invalid ${kind} template ${key}`);
	return {
		rows,
		names,
		feature,
		properties
	};
}
function planNativeEntities({ preparedDescriptors, baseline, previousLedger = [], dataLedger = [] }) {
	const bases = {
		plant: readBaseline(baseline, "plant"),
		zombie: readBaseline(baseline, "zombie")
	};
	const previous = /* @__PURE__ */ new Map(), previousNames = /* @__PURE__ */ new Map(), previousSlots = /* @__PURE__ */ new Set();
	for (const entry of previousLedger) {
		if (!plain(entry) || typeof entry.id !== "string" || !entry.id || !bases[entry.kind] || typeof entry.codename !== "string" || !entry.codename || !Number.isSafeInteger(entry.engineId) || entry.engineId < 0 || previous.has(entry.id) || previousNames.has(`${entry.kind}:${entry.codename}`) || previousSlots.has(`${entry.kind}:${entry.engineId}`)) fail("ENTITY_LEDGER_INVALID", "Invalid or conflicting previous entity identity");
		previous.set(entry.id, entry);
		previousNames.set(`${entry.kind}:${entry.codename}`, entry.id);
		previousSlots.add(`${entry.kind}:${entry.engineId}`);
	}
	const inputs = /* @__PURE__ */ new Map(), allNames = new Set(Object.entries(bases).flatMap(([kind, base]) => [...base.names].map((name) => `${kind}:${name}`)));
	for (const descriptor of preparedDescriptors) for (const entity of descriptor.entities) {
		const key = `${descriptor.namespace}:${entity.id}`;
		if (entity.key !== key || !bases[entity.kind] || !plain(entity.feature) || !plain(entity.properties) || inputs.has(key)) fail("ENTITY_IDENTITY_CONFLICT", `Invalid or duplicate entity: ${key}`);
		const codename = codenameFor(descriptor.namespace, entity.id);
		const nameKey = `${entity.kind}:${codename}`;
		if (allNames.has(nameKey)) fail("ENTITY_IDENTITY_CONFLICT", `Native codename collision: ${key}`);
		if (previousNames.has(nameKey) && previousNames.get(nameKey) !== key) fail("ENTITY_IDENTITY_CONFLICT", `Previous codename belongs to another identity: ${key}`);
		allNames.add(nameKey);
		const prior = previous.get(key);
		if (prior && (prior.kind !== entity.kind || prior.codename !== codename)) fail("ENTITY_IDENTITY_CONFLICT", `Previous identity changed: ${key}`);
		for (const field of [
			"ID",
			"CODENAME",
			"PROPS",
			"RES",
			"ALMANAC"
		]) if (Object.hasOwn(entity.feature, field)) fail("ENTITY_DATA_INVALID", `Reserved feature field: ${field}`);
		inputs.set(key, {
			descriptor,
			entity,
			key,
			codename,
			prior
		});
	}
	const entities = [], identityChanges = [];
	for (const kind of ["plant", "zombie"]) {
		const base = bases[kind];
		const items = [...inputs.values()].filter((item) => item.entity.kind === kind).sort((a, b) => {
			if (a.prior && b.prior) return a.prior.engineId - b.prior.engineId;
			if (a.prior) return -1;
			if (b.prior) return 1;
			return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
		});
		for (const [offset, item] of items.entries()) {
			const { descriptor, entity, key, codename, prior } = item;
			const engineId = base.rows.length + offset;
			const feature = merge(base.feature, entity.feature);
			const properties = merge(base.properties, entity.properties);
			for (const field of kind === "plant" ? [
				"Toughness",
				"SunCost",
				"Cooldown"
			] : [
				"Toughness",
				"WalkSPS",
				"EatDPS"
			]) if (!Number.isFinite(properties[field]) || properties[field] < 0) fail("ENTITY_DATA_INVALID", `Invalid ${key} ${field}`);
			if (!plain(feature.NAME) || kind === "plant" && !Array.isArray(feature.TAGS)) fail("ENTITY_DATA_INVALID", `Invalid ${key} feature structure`);
			const propsType = kind === "plant" ? "PlantProps" : "ZombieProps";
			feature.CODENAME = codename;
			feature.PROPS = `RTID(${codename}@${propsType})`;
			feature._CARDSPRITENAME = "Idle";
			if (kind === "plant") {
				feature.ID = engineId;
				feature.COSTUME = 0;
				feature.RES = {
					Plant: codename,
					Disabled: codename
				};
			} else {
				feature.RES = codename;
				feature.SubZombieList = [];
			}
			const almanacRecord = entity.almanac ? {
				objclass: kind === "plant" ? "PlantAlmanacProperties" : "ZombieAlmanacProperties",
				aliases: [codename],
				objdata: structuredClone(entity.almanac)
			} : null;
			if (entity.listed && !almanacRecord) fail("ENTITY_DATA_INVALID", `Listed entity needs independent almanac: ${key}`);
			if (almanacRecord) feature.ALMANAC = `RTID(${codename}@${kind === "plant" ? "PlantAlmanac" : "ZombieAlmanac"})`;
			else delete feature.ALMANAC;
			const typeRecord = {
				[kind === "plant" ? "PlantBasedOn" : "ZombieBasedOn"]: codename,
				Properties: feature.PROPS
			};
			entities.push({
				id: key,
				namespace: descriptor.namespace,
				localId: entity.id,
				kind,
				engineId,
				codename,
				contentDigest: descriptor.contentDigest,
				behavior: entity.behavior,
				visual: entity.visual,
				sounds: structuredClone(entity.sounds),
				feature,
				properties,
				typeRecord,
				listed: entity.listed === true,
				almanacRecord,
				almanac: {
					ready: !!almanacRecord,
					source: almanacRecord ? "owned" : "absent",
					reference: feature.ALMANAC ?? null
				}
			});
			if (prior && prior.engineId !== engineId) identityChanges.push({
				id: key,
				kind,
				previousEngineId: prior.engineId,
				engineId,
				reason: "native-baseline-or-contiguous-order-changed"
			});
		}
	}
	const ledger = entities.map(({ id, kind, engineId, codename }) => ({
		id,
		kind,
		engineId,
		codename
	}));
	const ids = new Set(ledger.map((entry) => entry.id));
	for (const entry of dataLedger) {
		if (entry.origin !== "data" || !bases[entry.kind] || bases[entry.kind].rows[entry.engineId]?.CODENAME !== entry.codename || entry.id !== `data:${entry.kind}:${hex(entry.codename)}` || ids.has(entry.id)) fail("ENTITY_LEDGER_INVALID", "Invalid data entity ledger");
		ids.add(entry.id);
		const prior = previous.get(entry.id);
		if (prior && (prior.kind !== entry.kind || prior.codename !== entry.codename)) fail("ENTITY_IDENTITY_CONFLICT", "Data entity identity changed");
		if (prior && prior.engineId !== entry.engineId) identityChanges.push({
			id: entry.id,
			kind: entry.kind,
			previousEngineId: prior.engineId,
			engineId: entry.engineId,
			reason: "data-array-order-changed"
		});
		ledger.push(structuredClone(entry));
	}
	return freeze({
		entities,
		ledger,
		removed: previousLedger.filter((entry) => !ids.has(entry.id)).map((entry) => structuredClone(entry)),
		identityChanges,
		baselineCounts: {
			plant: bases.plant.rows.length,
			zombie: bases.zombie.rows.length
		}
	});
}
//#endregion
//#region mods/entities/src/entity-native-assets.js
function prepareNativeEntityAssets(plan, { cc, native, decodedOwners, behaviorFactories }) {
	const PrefabInfo = native?.PrefabInfo;
	if (typeof PrefabInfo !== "function") throw new Error("Native PrefabInfo metadata class is unavailable");
	if (!cc?.Node || !cc.Prefab || !cc.UITransform || !cc.dragonBones?.ArmatureDisplay || !cc._decorator?.ccclass || !cc.js?.unregisterClass) throw new Error("Native prefab construction API is unavailable");
	const records = /* @__PURE__ */ new Map(), cleanups = [];
	const releaseMedia = [];
	let state = "prepared";
	const token = crypto.randomUUID();
	const dispose = () => {
		if (state === "in-use") throw Object.assign(/* @__PURE__ */ new Error("Published entity assets require restart"), { code: "ENTITY_RESTART_REQUIRED" });
		if (state === "disposed") return false;
		state = "disposed";
		records.clear();
		const errors = [];
		for (const cleanup of cleanups.splice(0).reverse()) try {
			cleanup();
		} catch (error) {
			errors.push(error);
		}
		if (errors.length) throw new AggregateError(errors, "Native entity asset cleanup failed");
		for (const release of releaseMedia.splice(0)) release();
		return true;
	};
	const node = (name) => {
		const result = new cc.Node(name);
		cleanups.push(() => result.destroy());
		return result;
	};
	const build = (entity, visual, Class, displayOnly) => {
		const dimensions = JSON.parse(visual.atlas.atlasJson);
		if (!(dimensions.width > 0) || !(dimensions.height > 0)) throw new Error("Native visual has invalid dimensions");
		const root = node(`gpn:${entity.id}:${entity.contentDigest}:${token}:${displayOnly ? "display" : "entity"}`);
		root.addComponent(cc.UITransform).setContentSize(dimensions.width, dimensions.height);
		const body = new cc.Node("Body");
		body.parent = root;
		body.addComponent(cc.UITransform).setContentSize(dimensions.width, dimensions.height);
		const db = body.addComponent(cc.dragonBones.ArmatureDisplay);
		db._dragonAsset = visual.skeleton;
		db._dragonAtlasAsset = visual.atlas;
		db._armatureName = visual.armature;
		db.animationName = "Idle";
		if (entity.kind === "plant") root.addComponent(native.AnimationController);
		if (!displayOnly) {
			if (Object.keys(entity.sounds || {}).length) {
				if (!cc.AudioSource) throw new Error("Native AudioSource is unavailable");
				root.addComponent(cc.AudioSource);
			}
			const component = root.addComponent(Class);
			if (entity.kind === "zombie") component.body = body.addComponent(native.BodyGrouper);
		}
		const prefab = new cc.Prefab();
		cleanups.push(() => prefab.destroy());
		prefab.name = root.name;
		prefab.data = root;
		const info = new PrefabInfo();
		info.asset = prefab;
		info.root = root;
		root._prefab = info;
		return prefab;
	};
	try {
		for (const entity of plan.entities) {
			if (!["plant", "zombie"].includes(entity.kind) || records.has(entity.id)) throw new Error("Invalid or duplicate planned entity");
			const owner = decodedOwners.get(entity.namespace);
			if (!owner || owner.namespace !== entity.namespace || owner.contentDigest !== entity.contentDigest) throw new Error(`Decoded resource identity differs: ${entity.id}`);
			const visual = owner.get(entity.visual);
			if (visual?.kind !== "dragonbones") throw new Error(`Missing native visual: ${entity.id}`);
			const sounds = Object.create(null);
			for (const [eventName, id] of Object.entries(entity.sounds || {})) {
				const sound = owner.get(id);
				if (sound?.kind !== "audio" || !sound.clip) throw new Error(`Missing native sound: ${entity.id}`);
				sounds[eventName] = sound.clip;
			}
			releaseMedia.push(owner.retain({
				entityId: entity.id,
				kind: "native-prefab",
				resourceIds: [entity.visual, ...Object.values(entity.sounds || {})]
			}));
			const context = Object.freeze({ sounds: Object.freeze(sounds) });
			const Base = entity.kind === "plant" ? native.Plant : native.Zombie;
			if (typeof Base !== "function" || typeof native.AnimationController !== "function" || typeof native.BodyGrouper !== "function") throw new Error("Native entity classes unavailable");
			const behaviorKey = entity.behavior.includes(":") ? entity.behavior : `${entity.namespace}:${entity.behavior}`;
			const factory = behaviorFactories.get(behaviorKey);
			if (typeof factory !== "function") throw new Error(`Missing entity behavior: ${entity.id}`);
			const Behavior = factory(Base, context);
			if (typeof Behavior !== "function" || Behavior === Base || !(Behavior.prototype instanceof Base)) throw new Error(`Behavior must return a native subclass: ${entity.id}`);
			class OwnedBehavior extends Behavior {}
			cleanups.push(() => cc.js.unregisterClass(OwnedBehavior));
			cc._decorator.ccclass(`gpn.entity.${entity.id}.${token}`)(OwnedBehavior);
			const prefab = build(entity, visual, OwnedBehavior, false);
			const displayPrefab = entity.kind === "plant" ? build(entity, visual, OwnedBehavior, true) : null;
			records.set(entity.id, Object.freeze({
				kind: entity.kind,
				engineId: entity.engineId,
				codename: entity.codename,
				behaviorClass: OwnedBehavior,
				entity: prefab,
				display: displayPrefab
			}));
		}
		return Object.freeze({
			get(id) {
				if (state === "disposed") throw new Error("Native entity assets are disposed");
				return records.get(id) || null;
			},
			markInUse() {
				if (state === "disposed") throw new Error("Native entity assets are disposed");
				if (state === "in-use") return false;
				state = "in-use";
				return true;
			},
			dispose
		});
	} catch (error) {
		try {
			dispose();
		} catch (cleanupError) {
			throw new AggregateError([error, cleanupError], "Native entity preparation and cleanup failed");
		}
		throw error;
	}
}
//#endregion
//#region mods/entities/src/entity-native-registration.js
function prepareNativeEntityRegistration({ cc, modules, plan, baseline, prefabs }) {
	const { plants, PlantEnum, Plants } = modules.Plants;
	const { zombies, ZombieEnum, Zombies } = modules.Zombies;
	const objects = modules.JSONs.PvZ2Object;
	const rows = {
		plant: baseline.plantFeatures.PLANTS,
		zombie: baseline.zombieFeatures.ZOMBIES
	};
	const before = {
		plant: JSON.stringify(rows.plant),
		zombie: JSON.stringify(rows.zombie)
	};
	const lists = [{
		data: baseline.plantFeatures,
		field: "SEEDCHOOSERDEFAULTORDER",
		kind: "plant"
	}, {
		data: baseline.zombieFeatures,
		field: "ALMANAC",
		kind: "zombie"
	}].map((entry) => ({
		...entry,
		value: entry.data[entry.field],
		length: entry.data[entry.field]?.length,
		before: JSON.stringify(entry.data[entry.field])
	}));
	const definitions = plan.entities.map((entity) => ({
		...entity,
		feature: structuredClone(entity.feature),
		properties: structuredClone(entity.properties),
		typeRecord: structuredClone(entity.typeRecord)
	}));
	const byId = (kind) => new Map(definitions.filter((entity) => entity.kind === kind).map((entity) => [entity.engineId, entity]));
	const plantIds = byId("plant"), zombieIds = byId("zombie");
	const plantNames = new Map([...plantIds.values()].map((entity) => [entity.codename, entity]));
	const zombieNames = new Map([...zombieIds.values()].map((entity) => [entity.codename, entity]));
	if (typeof plants.getFilledPlantProps !== "function" || typeof zombies.getFilledZombieProps !== "function") throw new Error("Native property constructors are unavailable");
	const prefabMap = new Map(definitions.map((entity) => [entity.id, prefabs.get(entity.id)]));
	for (const entity of definitions) {
		const entry = prefabMap.get(entity.id);
		if (!entry?.entity || entity.kind === "plant" && !entry.display) throw new Error(`Missing prepared native prefabs: ${entity.id}`);
	}
	for (const entry of lists) {
		if (!Array.isArray(entry.value)) throw new Error(`Missing native content list: ${entry.field}`);
		entry.additions = definitions.filter((entity) => entity.kind === entry.kind && entity.listed).map((entity) => {
			if (!entity.almanac?.ready || !entity.almanacRecord?.objdata) throw new Error(`Listed entity needs owned almanac data: ${entity.id}`);
			if (entry.value.includes(entity.codename)) throw new Error(`Duplicate native list entry: ${entity.id}`);
			return entity.codename;
		});
	}
	const writes = [];
	let state = "prepared";
	const cold = () => {
		if (cc.director.getScene() || plants.plantRes || zombies.zombieRes) throw new Error("Entity registration requires a cold startup before native resources");
	};
	const assign = (target, key, value, fresh = false) => {
		const original = Object.getOwnPropertyDescriptor(target, key);
		if (fresh && key in target) throw new Error(`Native entity identity collision: ${key}`);
		if (!original && !Object.isExtensible(target) || original && !original.configurable && (!original.writable || !Object.hasOwn(original, "value"))) throw new Error(`Native registration property is immutable: ${key}`);
		writes.push({
			target,
			key,
			original,
			value
		});
	};
	const wrap = (target, key, choose) => {
		const original = target[key];
		if (typeof original !== "function") throw new Error(`Missing native method: ${key}`);
		assign(target, key, function(...args) {
			const match = choose(...args);
			return match ? match() : original.apply(this, args);
		});
	};
	for (const [kind, enumeration, countKey] of [[
		"plant",
		PlantEnum,
		"amount"
	], [
		"zombie",
		ZombieEnum,
		"zombieAmount"
	]]) {
		if (rows[kind].length !== plan.baselineCounts[kind] || enumeration[countKey] !== rows[kind].length) throw new Error(`Native ${kind} baseline differs from the plan`);
		const entries = definitions.filter((entity) => entity.kind === kind);
		for (const [index, entity] of entries.entries()) {
			if (entity.engineId !== rows[kind].length + index) throw new Error(`Non-contiguous native ${kind} identity`);
			assign(enumeration, entity.codename, entity.engineId, true);
			const previous = enumeration[entity.engineId];
			if (previous !== void 0 && previous !== countKey) throw new Error(`Occupied native ${kind} ID: ${entity.engineId}`);
			assign(enumeration, String(entity.engineId), entity.codename);
		}
		if (entries.length) assign(enumeration, countKey, rows[kind].length + entries.length);
	}
	wrap(plants, "getPlantEnumByCodename", (name) => plantNames.has(name) && (() => plantNames.get(name).engineId));
	wrap(plants, "getPlantProps", (id) => plantIds.has(id) && (() => plantIds.get(id).properties));
	wrap(plants, "getPlantType", (name) => plantNames.has(name) && (() => plantNames.get(name).typeRecord));
	wrap(plants, "getPlantEnumWithPropByPlantTypes", (name) => plantNames.has(name) && (() => {
		const entity = plantNames.get(name);
		return {
			id: entity.engineId,
			prop: plants.getFilledPlantProps(structuredClone(entity.properties), entity.engineId),
			// Native plant counting and Supernova's smash compare type records by identity.
			filled_type: entity.typeRecord
		};
	}));
	wrap(plants, "loadPlantsInCard", (id, disabledOnly) => plantIds.has(id) && (async () => {
		const entry = prefabMap.get(plantIds.get(id).id);
		return {
			plantDIS: entry.display,
			plantPLANT: disabledOnly ? void 0 : entry.entity
		};
	}));
	wrap(zombies, "getZombiePropsByID", (id) => zombieIds.has(id) && (() => zombieIds.get(id).properties));
	wrap(zombies, "getZombieType", (name) => zombieNames.has(name) && (() => zombieNames.get(name).typeRecord));
	wrap(zombies, "getZombieEnumWithPropByZombieTypes", (name) => zombieNames.has(name) && (() => {
		const entity = zombieNames.get(name);
		return {
			z: entity.engineId,
			prop: zombies.getFilledZombieProps(structuredClone(entity.properties), entity.engineId),
			filled_type: structuredClone(entity.typeRecord)
		};
	}));
	wrap(zombies, "loadZombieByID", (id) => zombieIds.has(id) && (async () => prefabMap.get(zombieIds.get(id).id).entity));
	const almanacs = new Map(definitions.filter((entity) => entity.almanac?.ready).map((entity) => [entity.feature.ALMANAC, structuredClone(entity.almanacRecord)]));
	if (typeof objects.getObjects !== "function") throw new Error("Native object filtering is unavailable");
	wrap(objects, "getObjectsByRTID", (rtid, className) => almanacs.has(rtid) && (() => {
		const record = structuredClone(almanacs.get(rtid));
		return objects.getObjects(record.aliases[0], [record], className);
	}));
	for (const [Class, field, expected, kind] of [[
		Plants,
		"CardsFeatureJson",
		baseline.plantFeatures,
		"plant"
	], [
		Zombies,
		"zombieFeaturesJson",
		baseline.zombieFeatures,
		"zombie"
	]]) {
		wrap(Class.prototype, "onLoad", function() {
			return false;
		});
		const write = writes.at(-1);
		const original = Class.prototype.onLoad;
		write.value = function(...args) {
			if (this[field]?.json !== expected || expected[kind === "plant" ? "PLANTS" : "ZOMBIES"] !== rows[kind]) throw new Error(`Native ${kind} feature asset changed after startup preparation`);
			return original.apply(this, args);
		};
	}
	const restore = () => {
		for (const { target, key, original } of [...writes].reverse()) if (original) Object.defineProperty(target, key, original);
		else delete target[key];
		rows.plant.splice(plan.baselineCounts.plant);
		rows.zombie.splice(plan.baselineCounts.zombie);
		for (const entry of lists) entry.value.splice(entry.length);
	};
	return Object.freeze({
		publish() {
			cold();
			if (state !== "prepared") throw new Error("Entity registration was already published or disposed");
			for (const [kind, data, field] of [[
				"plant",
				baseline.plantFeatures,
				"PLANTS"
			], [
				"zombie",
				baseline.zombieFeatures,
				"ZOMBIES"
			]]) if (data[field] !== rows[kind] || JSON.stringify(rows[kind]) !== before[kind]) throw new Error(`Native ${kind} baseline changed during preparation`);
			for (const entry of lists) if (entry.data[entry.field] !== entry.value || JSON.stringify(entry.value) !== entry.before) throw new Error(`Native content list changed: ${entry.field}`);
			for (const { target, key, original } of writes) {
				const current = Object.getOwnPropertyDescriptor(target, key);
				if (Boolean(current) !== Boolean(original) || original && Reflect.ownKeys(original).some((field) => current[field] !== original[field])) throw new Error(`Native method or identity changed: ${key}`);
			}
			try {
				for (const { target, key, original, value } of writes) Object.defineProperty(target, key, original && Object.hasOwn(original, "value") ? {
					...original,
					value
				} : {
					value,
					configurable: true,
					writable: true,
					enumerable: true
				});
				rows.plant.push(...definitions.filter((entity) => entity.kind === "plant").map((entity) => entity.feature));
				rows.zombie.push(...definitions.filter((entity) => entity.kind === "zombie").map((entity) => entity.feature));
				for (const entry of lists) entry.value.push(...entry.additions);
				state = "published";
			} catch (error) {
				try {
					restore();
				} catch (cleanup) {
					throw new AggregateError([error, cleanup], "Native registration and restoration failed");
				}
				state = "disposed";
				throw error;
			}
		},
		markRunning() {
			if (state !== "published") throw new Error("Publish native entities before starting the game");
			prefabs.markInUse();
			state = "running";
		},
		dispose() {
			if (state === "disposed") return false;
			if (state === "running") throw new Error("Restart before removing native entity registration");
			cold();
			if (state === "published") restore();
			state = "disposed";
			return true;
		}
	});
}
//#endregion
//#region mods/entities/src/entity-native-icons.js
function prepareNativeEntityIcons(plan, { modules, decodedOwners }) {
	const visuals = {
		plant: /* @__PURE__ */ new Map(),
		zombie: /* @__PURE__ */ new Map()
	};
	for (const entity of plan.entities) {
		const owner = decodedOwners.get(entity.namespace);
		if (!owner || owner.namespace !== entity.namespace || owner.contentDigest !== entity.contentDigest) throw new Error(`Icon resource identity differs: ${entity.id}`);
		const visual = owner.get(entity.visual);
		if (visual?.kind !== "dragonbones" || !visual.skeleton || !visual.atlas || !visual.armature || !visuals[entity.kind] || visuals[entity.kind].has(entity.engineId)) throw new Error(`Invalid native icon: ${entity.id}`);
		visuals[entity.kind].set(entity.engineId, visual);
	}
	const bindings = /* @__PURE__ */ new WeakMap();
	const rollbackDisplays = /* @__PURE__ */ new Set();
	let state = "prepared";
	const select = (display, visual) => {
		if (!display) throw new Error("Native icon display is unavailable");
		if (visual) {
			if (!bindings.has(display)) {
				bindings.set(display, {
					dragonAsset: display.dragonAsset,
					dragonAtlasAsset: display.dragonAtlasAsset,
					armatureName: display.armatureName
				});
				if (state !== "in-use") rollbackDisplays.add(display);
			}
			display.dragonAsset = visual.skeleton;
			display.dragonAtlasAsset = visual.atlas;
			display.armatureName = visual.armature;
		} else if (bindings.has(display)) {
			const previous = bindings.get(display);
			display.dragonAsset = previous.dragonAsset;
			display.dragonAtlasAsset = previous.dragonAtlasAsset;
			display.armatureName = previous.armatureName;
			bindings.delete(display);
			rollbackDisplays.delete(display);
		}
	};
	const targetVisual = (kind, target) => {
		const amount = plan.baselineCounts[kind] + visuals[kind].size;
		const id = Number.isFinite(target) ? (target % amount + amount) % amount : target;
		return visuals[kind].get(id);
	};
	const hooks = [];
	const hook = (Class, key, make) => {
		const target = Class?.prototype;
		const original = target && Object.getOwnPropertyDescriptor(target, key);
		if (!original?.configurable) throw new Error(`Native icon hook unavailable: ${key}`);
		const installed = make(original);
		hooks.push({
			target,
			key,
			original,
			installed
		});
	};
	hook(modules.CardFeature, "cardGrouperPlant", (original) => {
		if (typeof original.value !== "function") throw new Error("Native plant card method unavailable");
		return {
			...original,
			value: function(id = this.ID, ...rest) {
				select(this.ca._plantDB, targetVisual("plant", id));
				return original.value.call(this, id, ...rest);
			}
		};
	});
	hook(modules.PlantIcon, "switchPlant", (original) => {
		if (typeof original.value !== "function") throw new Error("Native plant icon method unavailable");
		return {
			...original,
			value: function(id, ...rest) {
				select(this.plantDB, visuals.plant.get(id));
				return original.value.call(this, id, ...rest);
			}
		};
	});
	const unknown = Object.getOwnPropertyDescriptor(modules.CardFeatureZombie?.prototype || {}, "isUnknown");
	if (typeof unknown?.set !== "function") throw new Error("Native zombie unknown setter unavailable");
	hook(modules.CardFeatureZombie, "cardGrouperZombie", (original) => {
		if (typeof original.value !== "function") throw new Error("Native zombie card method unavailable");
		return {
			...original,
			value: function(id = this.ID, ...rest) {
				select(this.ca._plantDB, targetVisual("zombie", id));
				const result = original.value.call(this, id, ...rest);
				if (this.isUnknown) {
					select(this.ca._plantDB, null);
					unknown.set.call(this, true);
				}
				return result;
			}
		};
	});
	hook(modules.CardFeatureZombie, "isUnknown", (original) => ({
		...original,
		set: function(value) {
			if (value) select(this.ca._plantDB, null);
			return original.set.call(this, value);
		}
	}));
	const matches = (a, b) => a && [
		"value",
		"get",
		"set",
		"configurable",
		"enumerable",
		"writable"
	].every((key) => a[key] === b[key]);
	const releaseMedia = [];
	try {
		for (const entity of plan.entities) releaseMedia.push(decodedOwners.get(entity.namespace).retain({
			entityId: entity.id,
			kind: "native-icon",
			resourceIds: [entity.visual]
		}));
	} catch (error) {
		for (const release of releaseMedia) release();
		throw error;
	}
	return Object.freeze({
		install() {
			if (state === "disposed") throw new Error("Native icon adapter is disposed");
			if (state !== "prepared") return false;
			for (const item of hooks) if (!matches(Object.getOwnPropertyDescriptor(item.target, item.key), item.original)) throw new Error(`Native icon hook changed: ${item.key}`);
			const applied = [];
			try {
				for (const item of hooks) {
					Object.defineProperty(item.target, item.key, item.installed);
					applied.push(item);
				}
			} catch (error) {
				for (const item of applied.reverse()) Object.defineProperty(item.target, item.key, item.original);
				throw error;
			}
			state = "installed";
			return true;
		},
		markInUse() {
			if (state === "in-use") return false;
			if (state !== "installed") throw new Error("Install native icon routes before publication");
			state = "in-use";
			rollbackDisplays.clear();
			return true;
		},
		dispose() {
			if (state === "in-use") throw Object.assign(/* @__PURE__ */ new Error("Published native icon routes require restart"), { code: "ENTITY_RESTART_REQUIRED" });
			if (state === "disposed") return false;
			if (state === "installed") {
				for (const item of hooks) if (!matches(Object.getOwnPropertyDescriptor(item.target, item.key), item.installed)) throw new Error(`Native icon hook ownership lost: ${item.key}`);
				for (const display of rollbackDisplays) select(display, null);
				for (const item of [...hooks].reverse()) Object.defineProperty(item.target, item.key, item.original);
			}
			state = "disposed";
			visuals.plant.clear();
			visuals.zombie.clear();
			for (const release of releaseMedia.splice(0)) release();
			return true;
		}
	});
}
//#endregion
//#region mods/entities/src/startup-native-data.js
async function loadStartupNativeData(cc, { signal } = {}) {
	const assertCold = () => {
		signal?.throwIfAborted();
		if (cc.director.getScene()) throw new Error("Native data preparation requires a cold startup");
	};
	assertCold();
	const bundle = await new Promise((resolve, reject) => cc.assetManager.loadBundle("resources", (error, value) => error ? reject(error) : resolve(value)));
	assertCold();
	const entries = [
		[
			"plantFeatures",
			"json/Features/PlantFeatures",
			"PLANTS"
		],
		[
			"zombieFeatures",
			"json/Features/ZombieFeatures",
			"ZOMBIES"
		],
		[
			"plantProps",
			"json/Objects/PlantProps",
			"objects"
		],
		[
			"zombieProps",
			"json/Objects/ZombieProps",
			"objects"
		],
		[
			"plantTypes",
			"json/Objects/PlantTypes",
			"objects"
		],
		[
			"plantAlmanac",
			"json/Objects/PlantAlmanac",
			"objects"
		]
	];
	const data = {};
	for (const [key, path, field] of entries) {
		const asset = await new Promise((resolve, reject) => bundle.load(path, cc.JsonAsset, (error, value) => error ? reject(error) : resolve(value)));
		assertCold();
		if (!Array.isArray(asset?.json?.[field])) throw new Error(`Invalid native startup data: ${path}`);
		data[key] = asset.json;
	}
	return Object.freeze(data);
}
//#endregion
//#region mods/entities/src/main.js
var main_default = {
	startup(ctx) {
		const cc = ctx.engine.getCc();
		const module = (name) => ctx.engine.getSystemModule(`chunks:///_virtual/${name}.ts`);
		const modules = {
			Plants: module("Plants"),
			Zombies: module("Zombies"),
			JSONs: module("JSONs"),
			CardFeature: module("CardFeature").CardFeature,
			PlantIcon: module("PlantIcon").PlantIcon,
			CardFeatureZombie: module("CardFeatureZombie").CardFeatureZombie,
			native: {
				Plant: module("Plant").Plant,
				Zombie: module("Zombie").Zombie,
				AnimationController: module("AnimationController").AnimationController,
				BodyGrouper: module("BodyGrouper").BodyGrouper,
				PrefabInfo: cc.js.getClassByName("cc.PrefabInfo")
			}
		};
		const behaviors = /* @__PURE__ */ new Map(), owners = /* @__PURE__ */ new Map();
		let baseline, plan, prefabs, icons, registration;
		let accepting = true;
		ctx.registry.provide("entities", Object.freeze({ registerBehavior(namespace, id, factory) {
			if (!accepting) throw new Error("Entity behavior registration is closed");
			if (typeof factory !== "function") throw new Error("Expected behavior factory");
			const key = `${namespace}:${id}`;
			if (behaviors.has(key)) throw new Error(`Duplicate behavior: ${key}`);
			behaviors.set(key, factory);
		} }));
		ctx.registrations.add("entities", {
			async prepare({ previousIdentities, identities }) {
				accepting = false;
				const descriptors = [];
				for (const reader of contentReaders(ctx.files.own())) {
					const bytes = new Map(await Promise.all(reader.listPaths().map(async (path) => [path, await reader.readBytes(path)])));
					const snapshot = {
						digest: reader.contentDigest,
						readBytes: (path) => bytes.get(path) || null,
						readText: (path) => bytes.has(path) ? new TextDecoder().decode(bytes.get(path)) : null
					};
					const descriptor = prepareEntityContent({ meta: JSON.parse(snapshot.readText("pack.json")) }, snapshot);
					if (descriptor) descriptors.push(descriptor);
				}
				baseline = await loadStartupNativeData(cc);
				plan = planNativeEntities({
					preparedDescriptors: descriptors,
					baseline,
					previousLedger: previousIdentities,
					dataLedger: identities
				});
				for (const descriptor of descriptors) owners.set(descriptor.namespace, await decodeEntityContentResources(descriptor, { cc }));
				prefabs = prepareNativeEntityAssets(plan, {
					cc,
					native: modules.native,
					decodedOwners: owners,
					behaviorFactories: behaviors
				});
				icons = prepareNativeEntityIcons(plan, {
					modules,
					decodedOwners: owners
				});
				return { identities: plan.ledger.filter((entry) => !identities.some((prior) => prior.id === entry.id)) };
			},
			publish() {
				registration = prepareNativeEntityRegistration({
					cc,
					modules,
					plan,
					baseline,
					prefabs
				});
				registration.publish();
				icons.install();
				registration.markRunning();
				icons.markInUse();
				prefabs.markInUse();
			},
			async dispose() {
				const errors = [];
				for (const dispose of [
					() => icons?.dispose(),
					() => registration?.dispose(),
					() => prefabs?.dispose(),
					...[...owners.values()].reverse().map((owner) => () => owner.dispose())
				]) try {
					await dispose();
				} catch (error) {
					errors.push(error);
				}
				if (errors.length) throw new AggregateError(errors, "Entity framework cleanup failed");
			},
			getResources: () => [...owners.values()].map((owner) => owner.getConsumers())
		});
	},
	setup() {}
};
//#endregion
return main_default;

})();

const create_headbutter = (entityService, behaviorFiles) => {
const NS = 'gzh.headbutter'
const CODE = 'gpn_677a682e686561646275747465722e636f6e74656e74_686561646275747465726c657474756365'
const PURPLE_COSTUME = 0
const DEFAULTS = { HeadbuttDamage: 100, FoodDamage: 150, ButterDamage: 40, ButterChance: .1, ButterDuration: 8, MinButter: 3, MaxButter: 5, FoodButter: 3 }
// Each miss increases the chance above the reset value in ButterChance.
const BUTTER_PITY_GROWTH = 0.015770014206571696
const FOOD_LOOPS = 3
// PopAnim's duration uses the distance between each clip's first and last frames.
const FOOD_ACTIVE_SECONDS = (6 + FOOD_LOOPS * 20) / 30
const DEFAULT_PLANT_SCALE = .42
const EVENTS = {
  Play_Plant_HeadbutterLettuce_Attack: ['attack1', 'attack2', 'attack3'],
  Play_Plant_HeadbutterLettuce_Plantfood_Start: ['foodOn'],
  Play_Plant_HeadbutterLettuce_Plantfood_Loop: ['foodLoop1', 'foodLoop2'],
  Play_Plant_HeadbutterLettuce_Plantfood_End: ['foodOff'],
  Play_Plant_TurkeyPult_Plantfood_Start: ['water1', 'water2'],
}
let cardModules

function clipName(name, costume) {
  return costume === PURPLE_COSTUME ? 'Purple' + name : name
}

function placeBoardArt(control, squareWidth) {
  const placement = control.db.armature().getBone('boardPlacement')
  const ratio = squareWidth / 128 / DEFAULT_PLANT_SCALE
  placement.offset.scaleX = ratio
  placement.offset.scaleY = ratio
  // The lawn pivot is source y=224. Menus use the neutral rig.
  placement.offset.y = -36 * ratio
  placement.invalidUpdate()
}

function shuffled(values) {
  const result = [...values]
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}

return {
  startup(ctx) {
    const cc = ctx.engine.getCc()
    const module = name => ctx.engine.getSystemModule(`chunks:///_virtual/${name}.ts`)
    const { ZombiePool, TombPool, Rectangle, ZombieDamageDetails } = module('CharacterManager')
    const { PrjFunctions } = module('Projectiles')
    const { CharacterType } = module('Character')
    const { Zombie } = module('Zombie')
    const { FutureProtectorZombie } = module('FutureProtectorZombie')
    const { Tomb } = module('Tomb')
    const { Square } = module('Square')
    cardModules = {
      CardFeature: module('CardFeature').CardFeature,
      PlantIcon: module('PlantIcon').PlantIcon,
      plants: module('Plants').plants,
      player: module('PlayerProperties').AllPlayerProperties,
      AnimationController: module('AnimationController').AnimationController,
      UIInGame: module('UI').UIInGame,
      LnC: module('LnC').LnC,
      Square,
      director: cc.director,
    }
    const framework = entityService
    const files = behaviorFiles
    const logger = ctx.log
    const effects = {}
    const loadEffect = async name => {
      const [skeletonText, atlasText, png] = await Promise.all([
        files.readText(`fx/${name}_ske.json`), files.readText(`fx/${name}_tex.json`),
        files.readBytes(`fx/${name}.png`),
      ])
      const url = URL.createObjectURL(new Blob([png], { type: 'image/png' }))
      const image = new Image()
      try { image.src = url; await image.decode() } finally { URL.revokeObjectURL(url) }
      const texture = new cc.Texture2D()
      texture.image = new cc.ImageAsset(image)
      const skeleton = new cc.dragonBones.DragonBonesAsset()
      const atlas = new cc.dragonBones.DragonBonesAtlasAsset()
      skeleton.dragonBonesJson = skeletonText
      atlas.atlasJson = atlasText
      atlas.texture = texture
      effects[name] = { skeleton, atlas, texture }
    }
    ctx.registrations.add('headbutter-media', {
      async prepare() { await Promise.all(['hitfx','butterfx'].map(loadEffect)) },
      publish() {},
      dispose() {
        for (const effect of Object.values(effects)) {
          effect.skeleton.destroy(); effect.atlas.destroy(); effect.texture.destroy()
        }
      },
    })

    const live = z => z?.node?.isValid && z.node.activeInHierarchy && !z.dead && z.isAlive?.() !== false
    const zombieTargets = () => ZombiePool.pool().filter(z => live(z) && z.lobberTarget?.())
    const foodZombieTargets = () => {
      const right = Square.transFrom_ox_To_gx(820) // Original BoardPropertySheet.PlantTargetingXThreshold
      return ZombiePool.pool().filter(z =>
        live(z) && z.isRealZombie !== false && !z.potionInvisible && z.worldPositionX <= right)
    }
    const tombTargets = () => TombPool.pool().filter(tomb => live(tomb) && !tomb.hidden &&
      tomb.health > 0 && tomb.inLnC?.isInLawn())
    const artworkScale = () => Square.SquareWidth / 128
    const attackRect = (plant, x, y, width, height) => {
      const p = plant.worldPosition
      const sx = Square.SquareWidth / 64, sy = Square.SquareHeight / 76
      return Rectangle.createRectangleCenter(
        new cc.Vec2(p.x + (x + width / 2) * sx, p.y - (y + height / 2) * sy),
        width * sx, height * sy)
    }
    const body = target => target.bodyRecForShooter || target.bodyRec
    const inside = (target, rect) => live(target) && body(target) && rect.judgeCrossRec(body(target))
    const frontmost = targets => targets.sort((a, b) => body(a).prjX().x - body(b).prjX().x)[0]
    const meleeTarget = (plant, side) => {
      const lane = plant.inLane
      if (!lane) return
      const rect = attackRect(plant, side > 0 ? 4 : -98, -60, 102, 70)
      const zombie = frontmost(lane.zombiePool().filter(z => inside(z, rect)))
      if (zombie) return zombie
      const tombs = lane.tombPool().filter(live)
      return tombs.find(tomb => tomb.cIndex === plant.cIndex + side) ||
        tombs.find(tomb => tomb.cIndex === plant.cIndex)
    }
    const drawEffect = (name, clip, parent, position, scale) => {
      const effect = effects[name]
      if (!effect || !parent?.isValid) return
      const node = new cc.Node(`Headbutter ${name}`)
      node.parent = parent
      node.layer = parent.layer
      node.setWorldPosition(position)
      node.setScale(scale, scale, 1)
      const display = node.addComponent(cc.dragonBones.ArmatureDisplay)
      display.dragonAsset = effect.skeleton
      display.dragonAtlasAsset = effect.atlas
      display.armatureName = 'Body'
      display.once(cc.dragonBones.EventObject.COMPLETE, () => node.destroy())
      display.playAnimation(clip, 1)
    }
    const damage = (target, amount) => {
      target.dealDamage(new ZombieDamageDetails(amount, true, true, true, null))
    }

    framework.registerBehavior(NS, 'melee', (Base, { sounds }) => class HeadbutterLettuce extends Base {
      constructor(...args) {
        super(...args)
        Object.assign(this._objdataOwn, DEFAULTS)
      }

      specialPlantOnEnable() {
        this.action = ''
        this.side = 1
        this.butterMisses = 0
        this.foodLoops = 0
        this.foodTargets = new Set()
        this.anmControl.IdleAnim = 'Idle'
        this.anmControl.RandomAnim = []
        this.anmControl.WaterAnm = ['Water']
        this.anmControl.timeScaleDefault = 1
        placeBoardArt(this.anmControl, Square.SquareWidth)
        this.playIdle()
      }

      playClip(name) {
        this.action = name
        const costume = this.anmControl.currentCos
        this.anmControl.IdleAnim = clipName('Idle', costume)
        this.anmControl.playAnimation(clipName(name, costume), 1, 0, 1)
      }

      playIdle() {
        const roll = Math.random() * 125
        this.playClip(roll < 100 ? 'Idle' : roll < 120 ? 'Idle2' : 'Idle3')
      }

      specialPlantUpdate(delta, gameDelta) {
        if (this.fooding) {
          this.foodTime += gameDelta
          if (this.action === 'PlantFoodLoop' && this.foodTime > FOOD_ACTIVE_SECONDS) {
            this.foodEnd()
          }
          return
        }
        if (delta <= 0 || this.stunned > 0 ||
          (!this.action.startsWith('Idle') && this.action !== 'PlantFoodOff')) return
        if (meleeTarget(this, 1)) this.side = 1
        else if (meleeTarget(this, -1)) this.side = -1
        else return
        this.playClip(this.side > 0 ? 'Attack' : 'Attack2')
      }

      waterable() { return !this.fooding && !this.action?.startsWith('Attack') }

      water() {
        if (!this.dead && this.haveWaterAnimation && this.waterable()) this.playClip('Water')
      }

      specialPlantFood() {
        this.foodLoops = 0
        this.foodTime = 0
        this.foodTargets = new Set()
        this.side = 1
        this.playClip('PlantFoodOn')
      }

      specialPlantFoodEnd() {
        if (!this.dead && this.node?.isValid) this.playClip('PlantFoodOff')
      }

      animationOnComplete(event) {
        const name = event.animationState?.name.replace(/^Purple/, '')
        if (this.dead || !this.node?.isValid || name !== this.action) return
        if (this.fooding) {
          if (this.foodLoops < FOOD_LOOPS && this.foodTime <= FOOD_ACTIVE_SECONDS) {
            this.foodLoops++
            this.foodPulse()
            this.playClip('PlantFoodLoop')
          } else this.foodEnd()
          return
        }
        this.playIdle()
      }

      animationListener(event) {
        const clip = event.animationState?.name.replace(/^Purple/, '')
        if (event.name === 'use_special' && !this.dead && clip === this.action) {
          if (clip === 'Attack' || clip === 'Attack2') this.strike(clip === 'Attack' ? 1 : -1)
          else if (clip === 'PlantFoodLoop' && this.fooding) {
            this.strike(this.side)
            this.side *= -1
          }
          return
        }
        if (event.name !== 'PlaySample') return
        const samples = EVENTS[event.data?.strings?.[0]]
        const audio = samples && sounds[samples[Math.floor(Math.random() * samples.length)]]
        if (audio) this.getComponent(cc.AudioSource)?.playOneShot(audio, 1)
      }

      getStat(key) {
        const base = this.objdataOwn[key] ?? DEFAULTS[key]
        const boost = this._MintBoosted ? { HeadbuttDamage: 415, FoodDamage: 500, ButterDamage: 220 }[key] || 0 : 0
        return base + boost
      }

      strike(side) {
        const p = this.node.worldPosition
        const point = new cc.Vec3(p.x + side * 80 * Square.SquareWidth / 64, p.y + 23 * Square.SquareHeight / 76, p.z)
        drawEffect('hitfx', side > 0 ? 'HitFX1' : 'HitFX2', this.inLane?.prjLayer, point, artworkScale())
        const target = meleeTarget(this, side)
        if (target) damage(target, this.getStat('HeadbuttDamage'))
        const baseChance = this.getStat('ButterChance')
        const missBonus = -Math.expm1(-BUTTER_PITY_GROWTH * this.butterMisses)
        const chance = baseChance + (1 - baseChance) * missBonus
        if (Math.random() >= chance) {
          this.butterMisses++
          return
        }
        const rect = attackRect(this, -96, -250, 187, 623)
        const lanes = [this.lIndex, this.lIndex - 1, this.lIndex + 1]
        const candidates = zombieTargets().filter(z => lanes.includes(z.lIndex) && inside(z, rect))
        if (this.fooding) {
          for (const lane of lanes) {
            const zombie = frontmost(candidates.filter(z => z.lIndex === lane))
            if (zombie && this.lobButter(zombie, false, side)) {
              this.butterMisses = 0
              return
            }
          }
          this.butterMisses++
          return
        }

        // Several zombies can redirect a lob to the same target.
        const targets = new Map()
        for (const zombie of candidates) {
          const aim = zombie.lobberTarget?.()
          if (live(aim) && !aim.potionInvisible) targets.set(aim, zombie)
        }
        const max = Math.min(this.getStat('MaxButter'), targets.size)
        const min = Math.min(this.getStat('MinButter'), max)
        const count = min + Math.floor(Math.random() * (max - min + 1))
        let launched = 0
        for (const [aim, zombie] of shuffled(targets.entries())) {
          if (launched >= count) break
          if (this.lobButter(zombie, false, 0, aim)) launched++
        }
        this.butterMisses = launched > 0 ? 0 : this.butterMisses + 1
      }

      foodPulse() {
        const zombies = foodZombieTargets()
        const tombs = tombTargets()
        const isNew = target => !this.foodTargets.has(target)
        const select = () => [...shuffled(zombies.filter(isNew)), ...tombs.filter(isNew)]
          .slice(0, this.getStat('FoodButter'))
        let selected = select()
        if (!selected.length && this.foodTargets.size) {
          this.foodTargets = new Set()
          selected = select()
        }
        const history = this.foodTargets
        for (const target of selected) {
          const launch = this.lobButter(target, true)
          if (!launch) continue
          // Reserve the target while Gardendless loads the projectile from its pool.
          history.add(target)
          launch.then(projectile => {
            if (!projectile) history.delete(target)
          })
        }
        const lane = this.inLane
        if (!lane) return
        const rect = attackRect(this, -98, -60, 205, 70)
        const amount = this.getStat('FoodDamage') * (this._dmgScale ?? 1)
        for (const target of [...lane.zombiePool(), ...lane.tombPool()]) {
          if (inside(target, rect)) damage(target, amount)
        }
      }

      lobButter(target, fromFood = false, side = 0, lockedAim = null) {
        const isTomb = fromFood && target instanceof Tomb
        if (!live(target)) return
        if (fromFood && target instanceof FutureProtectorZombie && target.shields?.some(live)) return
        const aim = fromFood ? target : lockedAim ?? target.lobberTarget?.()
        if (!aim) return
        const p = this.worldPosition
        const start = new cc.Vec2(p.x + 15 * Square.SquareWidth / 64, p.y)
        const heightScale = Square.SquareHeight / 76
        const launchHeight = 95 * heightScale
        const endHeight = fromFood ? 40 * heightScale : aim.zombieHeight * Math.abs(aim.scale) + aim.height_depth
        const seconds = 1.2
        const ticksPerSecond = 60
        const flight = seconds * ticksPerSecond
        // The original projectile solver derives acceleration from ButterLobHeight in seconds.
        const gravity = (350 * heightScale - Math.max(launchHeight, endHeight)) /
          (seconds / 2 - seconds * seconds / 8) / (ticksPerSecond * ticksPerSecond)
        const parent = this.inLane?.prjLayer
        let destination
        if (isTomb) {
          if (!aim.inLnC?.isInLawn()) return
          destination = Square.getSquareWorldPosition(aim.lIndex, aim.cIndex)
        } else if (fromFood && aim.lobberToPos === Zombie.prototype.lobberToPos) {
          const speed = aim.getShouldSpeed() * aim.walkSpeedScaleExtra()
          const direction = Math.sign(aim.walkDir.x) * (aim.reversed ? -1 : 1)
          destination = new cc.Vec2(aim.worldPositionX + flight * speed * direction, aim.worldPositionY)
        } else {
          destination = aim.lobberToPos(flight)?.clone()
        }
        const amount = this.getStat('ButterDamage'), duration = this.getStat('ButterDuration')
        if (!parent?.isValid || !Number.isFinite(destination?.x) || !Number.isFinite(destination?.y)) return
        if (side && side * (destination.x - p.x) < 0) {
          destination.x = p.x + side * 32 * Square.SquareWidth / 64
        }
        return PrjFunctions.lobOneCabbageOnPos('butter', start, launchHeight, parent, destination, gravity, CharacterType.zombie, flight, endHeight)
          .then(projectile => {
            if (!projectile) return
            projectile.setDamage(amount).setButter(duration)
            if (fromFood) {
              projectile.size = new cc.Size(30 * Square.SquareWidth / 64, 30 * heightScale)
              if (live(aim)) projectile.targetLocked = aim
            }
            if (lockedAim) projectile.targetLocked = lockedAim
            const nativeParticle = projectile.playParticle
            const nativeDisable = projectile.characterOnDisable
            const ownParticle = Object.hasOwn(projectile, 'playParticle')
            const ownDisable = Object.hasOwn(projectile, 'characterOnDisable')
            const nativeDetect = projectile.detectEnemy
            const ownDetect = Object.hasOwn(projectile, 'detectEnemy')
            if (fromFood || lockedAim) {
              projectile.detectEnemy = function(...args) {
                if (lockedAim && (!live(lockedAim) || lockedAim.potionInvisible)) return
                if (this.targetLocked && !live(this.targetLocked)) this.targetLocked = null
                return nativeDetect.apply(this, args)
              }
            }
            projectile.characterOnDisable = function() {
              if (ownParticle) this.playParticle = nativeParticle
              else delete this.playParticle
              if (ownDisable) this.characterOnDisable = nativeDisable
              else delete this.characterOnDisable
              if (fromFood || lockedAim) {
                if (ownDetect) this.detectEnemy = nativeDetect
                else delete this.detectEnemy
              }
              return nativeDisable.call(this)
            }
            projectile.playParticle = function(position, particles) {
              if (particles?.length) return nativeParticle.call(this, position, particles)
              const point = position || this.realWorldPosition
              const fxParent = this.node?.parent
              drawEffect('butterfx', 'HitFX1', fxParent, new cc.Vec3(point.x, point.y, 0), .42)
            }
            return projectile
          })
          .catch(error => { logger.warn(`Headbutter butter: ${error.message}`) })
      }
    })
  },

  setup(ctx) {
    const { CardFeature, PlantIcon, plants, player, AnimationController, UIInGame, LnC, Square, director } = cardModules
    const originalByType = CardFeature.prototype.cardGrouperByTypePlant
    const originalCard = CardFeature.prototype.cardGrouperPlant
    const originalIcon = PlantIcon.prototype.switchPlant
    const originalReadCostume = AnimationController.prototype.readCostume
    const originalSwitchCostume = AnimationController.prototype.switchCostume
    const originalRollCostume = AnimationController.prototype.rollCostumeUp
    const originalGetToday = player.getToday
    const boundCards = new WeakSet()
    let nativeCardVisual
    let headbutterCardAsset
    const isHeadbutter = id => plants.getPlantFeature(id)?.CODENAME === CODE
    const showPortrait = (display, properties) => {
      const forcedCostume = properties?.CostumeOnSpawn
      const costume = Number.isFinite(forcedCostume) ? forcedCostume : player.currentPlayer?.plantProps?.[CODE]?.costume
      display.playAnimation(clipName('SeedPacket', costume), 1)
    }
    const isHeadbutterVisual = control => control.node.name.startsWith(`gpn:${NS}.content:headbutterlettuce:`)
    const positionPreview = control => {
      const parent = control.node.parent
      if (parent === UIInGame.component?.plantInHandLayer || parent?.parent?.getComponent(LnC)?.ghostPoint === parent) {
        placeBoardArt(control, Square.SquareWidth)
      }
    }
    const bindCardByType = function(...args) {
      const display = this.ca._plantDB
      // The seed chooser clones its first card after that card has been assigned a plant.
      if (headbutterCardAsset && display.dragonAsset === headbutterCardAsset && !boundCards.has(display)) {
        if (nativeCardVisual) Object.assign(display, nativeCardVisual)
      } else if (display.armature()?.animation.hasAnimation('kernelpult')) {
        nativeCardVisual = {
          dragonAsset: display.dragonAsset,
          dragonAtlasAsset: display.dragonAtlasAsset,
          armatureName: display.armatureName,
        }
      }
      return originalByType.apply(this, args)
    }
    const showSeedCard = function(...args) {
      const result = originalCard.apply(this, args)
      if (this.PF?.CODENAME === CODE) {
        const display = this.ca._plantDB
        headbutterCardAsset = display.dragonAsset
        boundCards.add(display)
        showPortrait(display, this.Prop)
      }
      return result
    }
    const showPlantIcon = function(...args) {
      const result = originalIcon.apply(this, args)
      if (isHeadbutter(this.ID)) showPortrait(this.plantDB)
      return result
    }
    const readPreviewCostume = function(...args) {
      const result = originalReadCostume.apply(this, args)
      if (isHeadbutterVisual(this) && this.node.name.endsWith(':display')) positionPreview(this)
      return result
    }
    const switchCostume = function(costume) {
      const result = originalSwitchCostume.call(this, costume)
      if (!isHeadbutterVisual(this)) return result
      this.IdleAnim = clipName('Idle', costume)
      const animation = this.db?.armature()?.animation
      const current = animation?.lastAnimationName
      // Let an attack already in progress finish with its original frame events.
      if (current && /^(?:Purple)?Idle[23]?$/.test(current)) {
        const next = clipName(current.replace(/^Purple/, ''), costume)
        if (next !== current) this.playAnimation(next, 1, 0, this.timeScale, true)
      }
      return result
    }
    const rollCostume = function(...args) {
      const result = originalRollCostume.apply(this, args)
      if (!isHeadbutterVisual(this)) return result
      const scene = director.getScene()
      for (const card of scene?.getComponentsInChildren(CardFeature) ?? []) {
        if (card.node.activeInHierarchy && card.PF?.CODENAME === CODE) showPortrait(card.ca._plantDB, card.Prop)
      }
      for (const icon of scene?.getComponentsInChildren(PlantIcon) ?? []) {
        if (icon.node.activeInHierarchy && isHeadbutter(icon.ID)) showPortrait(icon.plantDB)
      }
      return result
    }
    const getToday = function(...args) {
      const today = originalGetToday.apply(this, args)
      const progress = this.currentPlayer?.plantProps?.[CODE]
      if (!(progress?.progress > 0)) return today
      if (today.plantCostumeToday.some(offer => offer.plant_type === CODE && offer.costume === PURPLE_COSTUME)) return today
      return { ...today, plantCostumeToday: [...today.plantCostumeToday, { plant_type: CODE, costume: PURPLE_COSTUME }] }
    }
    CardFeature.prototype.cardGrouperByTypePlant = bindCardByType
    CardFeature.prototype.cardGrouperPlant = showSeedCard
    PlantIcon.prototype.switchPlant = showPlantIcon
    AnimationController.prototype.readCostume = readPreviewCostume
    AnimationController.prototype.switchCostume = switchCostume
    AnimationController.prototype.rollCostumeUp = rollCostume
    player.getToday = getToday
    ctx.runtime.onDispose(() => {
      if (CardFeature.prototype.cardGrouperByTypePlant === bindCardByType) CardFeature.prototype.cardGrouperByTypePlant = originalByType
      if (CardFeature.prototype.cardGrouperPlant === showSeedCard) CardFeature.prototype.cardGrouperPlant = originalCard
      if (PlantIcon.prototype.switchPlant === showPlantIcon) PlantIcon.prototype.switchPlant = originalIcon
      if (AnimationController.prototype.readCostume === readPreviewCostume) AnimationController.prototype.readCostume = originalReadCostume
      if (AnimationController.prototype.switchCostume === switchCostume) AnimationController.prototype.switchCostume = originalSwitchCostume
      if (AnimationController.prototype.rollCostumeUp === rollCostume) AnimationController.prototype.rollCostumeUp = originalRollCostume
      if (player.getToday === getToday) player.getToday = originalGetToday
    })
    ctx.plants.mutateFeatures(data => {
      if (Array.isArray(data.SANDBOX) && !data.SANDBOX.includes(CODE)) data.SANDBOX.push(CODE)
      const feature = data.PLANTS.find(plant => plant.CODENAME === CODE)
      if (feature) feature.COSTUME = 1
    })
    ctx.controls.definePanel({
      title: '奶油生菜',
      groups: [{
        title: '普通关卡',
        items: [{
          key: 'unlock', type: 'action', label: '解锁奶油生菜',
          onClick() {
            if (!ctx.plants.getFeature(CODE)) {
              ctx.ui.toast('请先启用奶油生菜内容包')
              return
            }
            const props = ctx.player.getProperty('plantProps')
            if (!props || typeof props !== 'object') {
              ctx.ui.toast('请先进入一个玩家存档')
              return
            }
            const previous = props[CODE]
            if (previous?.progress >= 1) {
              ctx.ui.toast('奶油生菜已解锁')
              return
            }
            const entry = { medal: false, costume: -1, costumes: [], boost: 0, ...previous, progress: 1, tutorialLevel: 1 }
            ctx.player.setProperty('plantProps', { ...props, [CODE]: entry })
            ctx.ui.toast('奶油生菜已解锁，重新进入关卡后可选用')
          },
        }],
      }],
    })
  },
}

};
const create_iceshroom = (entityService, behaviorFiles) => {
const NS = 'gzh.iceshroom'
const CODE = 'gpn_677a682e6963657368726f6f6d2e636f6e74656e74_6963657368726f6f6d'
const NATIVE_ART_TILE_WIDTH = 128
const ENGINE_PLANT_SCALE = .42
const DROP_DELAY = .8
const DROP_HEIGHT = 550
const DROP_VELOCITY = 1000
const DROP_ACCELERATION = 50
const DROP_SECONDS = (Math.sqrt(DROP_VELOCITY ** 2 + 2 * DROP_ACCELERATION * DROP_HEIGHT) - DROP_VELOCITY) / DROP_ACCELERATION
const live = entity => entity?.node?.isValid && entity.node.activeInHierarchy && !entity.dead && entity.isAlive?.() !== false
let modules

function placeBoardArt(control, squareWidth) {
  const placement = control.db?.armature()?.getBone('boardPlacement')
  if (!placement) return
  const scale = squareWidth / NATIVE_ART_TILE_WIDTH / ENGINE_PLANT_SCALE
  placement.offset.scaleX = scale
  placement.offset.scaleY = scale
  placement.invalidUpdate()
}

return {
  startup(ctx) {
    const cc = ctx.engine.getCc()
    const module = name => ctx.engine.getSystemModule(`chunks:///_virtual/${name}.ts`)
    const { PlantPool, ZombiePool, TombPool, Rectangle, ZombieDamageDetails } = module('CharacterManager')
    const { Square } = module('Square')
    const { plants } = module('Plants')
    modules = { plants, Square, CardFeature: module('CardFeature').CardFeature,
      PlantIcon: module('PlantIcon').PlantIcon, AnimationController: module('AnimationController').AnimationController,
      UIInGame: module('UI').UIInGame, LnC: module('LnC').LnC }
    const files = behaviorFiles
    const effects = {}
    let stats, audioMap
    const displays = new Set()
    const damageStates = new WeakMap()
    const width = () => Square.SquareWidth
    const height = () => Square.SquareHeight
    const artScale = () => width() / NATIVE_ART_TILE_WIDTH
    const remainingBoost = state => Math.max(1, ...[...state.sources].filter(([source, entry]) =>
      live(source) && source.iceClock < entry.until).map(([, entry]) => entry.multiplier))

    const grantBoost = (target, source, multiplier) => {
      let state = damageStates.get(target)
      if (!state) {
        const descriptor = Object.getOwnPropertyDescriptor(target, '_dmgScale')
        if (!descriptor?.configurable || !descriptor.writable) return
        state = { descriptor, base: descriptor.value, sources: new Map() }
        damageStates.set(target, state)
        Object.defineProperty(target, '_dmgScale', {
          configurable: true, enumerable: descriptor.enumerable,
          get: () => state.base * remainingBoost(state),
          set: value => { state.base = value },
        })
      }
      state.sources.set(source, { multiplier, until: source.iceClock + 2 })
      source.iceRecipients.add(target)
    }
    const revokeBoost = (target, source) => {
      const state = damageStates.get(target)
      if (!state) return
      state.sources.delete(source)
      if (!state.sources.size) {
        Object.defineProperty(target, '_dmgScale', { ...state.descriptor, value: state.base })
        damageStates.delete(target)
      }
    }

    async function loadEffect(name) {
      const [skeletonText, atlasText, png] = await Promise.all([
        files.readText(`fx/${name}_ske.json`), files.readText(`fx/${name}_tex.json`), files.readBytes(`fx/${name}.png`),
      ])
      const url = URL.createObjectURL(new Blob([png], { type: 'image/png' }))
      const image = new Image()
      try { image.src = url; await image.decode() } finally { URL.revokeObjectURL(url) }
      const texture = new cc.Texture2D()
      texture.image = new cc.ImageAsset(image)
      const skeleton = new cc.dragonBones.DragonBonesAsset()
      const atlas = new cc.dragonBones.DragonBonesAtlasAsset()
      skeleton.dragonBonesJson = skeletonText
      atlas.atlasJson = atlasText
      atlas.texture = texture
      effects[name] = { skeleton, atlas, texture }
    }
    ctx.registrations.add('iceshroom-media', {
      async prepare() {
        const [statText, soundText] = await Promise.all([
          files.readText('stats.json'), files.readText('audio.json'),
          ...['impact', 'melee', 'projectile', 'tile'].map(loadEffect),
        ])
        stats = JSON.parse(statText)
        audioMap = JSON.parse(soundText)
      },
      publish() {},
      dispose() {
        for (const node of displays) if (node.isValid) node.destroy()
        displays.clear()
        for (const { skeleton, atlas, texture } of Object.values(effects)) {
          skeleton.destroy(); atlas.destroy(); texture.destroy()
        }
      },
    })

    const remove = node => {
      displays.delete(node)
      if (node?.isValid) node.destroy()
    }
    function draw(name, clip, parent, position, playSound, loops = 1, completed) {
      if (!parent?.isValid || !effects[name]) return
      const node = new cc.Node(`Ice-shroom ${name}`)
      displays.add(node)
      node.parent = parent
      node.layer = parent.layer
      node.setWorldPosition(position)
      node.setScale(artScale(), artScale(), 1)
      const display = node.addComponent(cc.dragonBones.ArmatureDisplay)
      const { skeleton, atlas } = effects[name]
      display.dragonAsset = skeleton
      display.dragonAtlasAsset = atlas
      display.armatureName = 'Body'
      display.on(cc.dragonBones.EventObject.FRAME_EVENT, event => {
        if (event.name === 'PlaySample') playSound(event.data?.strings?.[0], node)
      })
      if (loops) display.on(cc.dragonBones.EventObject.COMPLETE, () => {
        if (completed) completed(display, node)
        else remove(node)
      })
      display.playAnimation(clip, loops)
      return node
    }

    const zombieLive = zombie => live(zombie) && zombie.isRealZombie !== false && !zombie.hypnotized && !zombie.potionInvisible
    const zombieCell = zombie => {
      if (!zombieLive(zombie) || zombie.worldPositionX > Square.transFrom_ox_To_gx(820)) return null
      const row = zombie.lIndex
      if (row < 0 || row >= Square.LaneCount) return null
      const left = Square.getSquareWorldPosition(row, 0).x
      const col = Math.floor((zombie.worldPositionX - left) / width() + .5)
      if (col < 0 || col >= Square.ColumnCount) return null
      const cell = Square.getLnC(row, col)
      return cell?.isInLawn() ? cell : null
    }
    const winterPlant = plant => plant.objdataOwn?.Family === 'Cold' || plant.Plant_Type_Data === CODE
    const hits = (x, y, w, h, entities) => {
      const rect = Rectangle.createRectangleCenter(new cc.Vec2(x, y), w, h)
      return entities.filter(target => {
        const body = target.bodyRecForShooter || target.bodyRec
        return body && rect.judgeCrossRec(body)
      })
    }
    const nearby = (x, y, r, entities) => hits(x, y, 2 * r * width(), 2 * r * height(), entities)
    const hurt = (target, amount) => target.dealDamage(new ZombieDamageDetails(amount, true, true, true, null))

    const framework = entityService
    framework.registerBehavior(NS, 'ice', (Base, { sounds }) => class IceShroom extends Base {
      specialPlantOnEnable() {
        this.iceClock = 0
        this.iceNextPulse = .5
        this.iceNextAttack = 0
        this.iceRecipients = new Set()
        this.iceShots = []
        this.iceTiles = []
        this.anmControl.IdleAnim = 'Idle'
        this.anmControl.RandomAnim = []
        this.anmControl.WaterAnm = ['Water']
        this.anmControl.timeScaleDefault = 1
        placeBoardArt(this.anmControl, width())
        this.playIdle()
      }
      specialPlantOnDisable() {
        for (const target of this.iceRecipients || []) revokeBoost(target, this)
        for (const { node } of this.iceShots || []) remove(node)
        for (const node of this.iceTiles || []) {
          const display = node.getComponent(cc.dragonBones.ArmatureDisplay)
          if (node.isValid && display?.isValid) display.playAnimation('End', 1)
        }
        this.iceRecipients?.clear()
      }
      stat(name) {
        const level = Math.max(0, Math.min(9, (this.objdataOwn.IceShroomLevel || 1) - 1))
        return stats.levels[name][level] + (this._MintBoosted ? stats.powerups[name]?.[level] || 0 : 0)
      }
      playClip(name) {
        this.action = name
        this.anmControl.playAnimation(name, 1, 0, 1)
      }
      playIdle() { this.playClip(Math.random() < 12 / 13 ? 'Idle' : 'Idle2') }
      waterable() { return !this.fooding && this.action?.startsWith('Idle') }
      water() { if (!this.dead && this.waterable()) this.playClip('Water') }
      specialPlantFood() { this.playClip('PlantFood'); this.queueIce() }
      specialPlantFoodEnd() { if (live(this)) this.playIdle() }
      animationOnComplete(event) {
        if (!live(this) || event.animationState?.name !== this.action) return
        if (this.fooding && this.action === 'PlantFood') this.foodEnd()
        else this.playIdle()
      }
      playIceSound(name, node = this.node) {
        const choices = audioMap[name]
        if (!choices?.length || !node?.isValid) return
        const audio = sounds['s' + choices[Math.floor(Math.random() * choices.length)]]
        if (audio) (node.getComponent(cc.AudioSource) || node.addComponent(cc.AudioSource)).playOneShot(audio, 1)
      }
      animationListener(event) {
        const clip = event.animationState?.name
        if (event.name === 'PlaySample') this.playIceSound(event.data?.strings?.[0])
        if (event.name !== 'use_special' || !live(this) || clip !== this.action) return
        if (clip === 'Attack') this.strike()
      }

      specialPlantUpdate(delta, gameDelta) {
        if (!(gameDelta > 0) || !this.inLane || !this.iceShots) return
        this.iceClock += gameDelta
        this.advanceShots()
        if (this.iceClock >= this.iceNextPulse) {
          this.iceNextPulse += 1
          this.pulseAura()
        }
        if (delta > 0 && !this.fooding && this.stunned <= 0 &&
            this.action.startsWith('Idle') && this.iceClock >= this.iceNextAttack && this.meleeTargets().length) {
          this.iceNextAttack = this.iceClock + 1.5
          this.playClip('Attack')
        }
      }

      meleeTargets() {
        const cell = Square.getSquareWorldPosition(this.lIndex, this.cIndex)
        // The native grid rectangle starts in the plant's own column and adds ActionDamageArea to its width.
        const columns = 1 + (this.cIndex > 7 ? 1 : this.stat('IceShroom_ActionDamageArea'))
        const targets = [...this.inLane.zombiePool().filter(zombieLive), ...this.inLane.tombPool().filter(live)]
        return hits(cell.x + (columns - 1) * width() / 2, cell.y, columns * width(), height(), targets)
      }
      strike() {
        for (const target of this.meleeTargets()) {
          const point = target.worldPosition
          draw('melee', 'Effect', this.inLane.prjLayer,
            new cc.Vec3(point.x - 80 * width() / 64, point.y + 125 * height() / 76, 0), this.playIceSound.bind(this))
          hurt(target, this.stat('ActionDamage') * this._dmgScale)
          target.setChill?.(this.stat('IceShroom_ActionChillDuration'))
        }
      }
      pulseAura() {
        const targets = new Set()
        for (const plant of PlantPool.pool()) {
          if (plant === this || !live(plant) || !winterPlant(plant) ||
              Math.abs(plant.lIndex - this.lIndex) > 1 || Math.abs(plant.cIndex - this.cIndex) > 1) continue
          targets.add(plant)
          grantBoost(plant, this, this.stat('IceShroom_AuraWinterMintDamageBoost'))
        }
        for (const target of this.iceRecipients) {
          if (!live(target) || (!targets.has(target) && this.iceClock >= damageStates.get(target)?.sources.get(this)?.until)) {
            revokeBoost(target, this)
            this.iceRecipients.delete(target)
          }
        }
        const iceCells = new Set()
        const spawnTiles = !this.iceTiles.length
        for (let row = this.lIndex - 1; row <= this.lIndex + 1; row++) {
          for (let col = this.cIndex - 1; col <= this.cIndex + 1; col++) {
            const cell = Square.getLnC(row, col)
            if (!cell?.isInLawn()) continue
            iceCells.add(cell)
            if (!spawnTiles) continue
            const point = Square.getSquareWorldPosition(row, col)
            const tile = draw('tile', 'Spawn', Square.getLane(row)?.icetileLayer,
              new cc.Vec3(point.x, point.y, 0), this.playIceSound.bind(this), 1,
              (display, node) => {
                if (display.armature()?.animation.lastAnimationName === 'End') remove(node)
                else display.playAnimation('Loop', 0)
              })
            if (tile) this.iceTiles.push(tile)
          }
        }
        for (const zombie of ZombiePool.pool()) {
          if (!zombieLive(zombie)) continue
          const col = Square.judgeCIndex(zombie.worldPositionX)
          if (iceCells.has(Square.getLnC(zombie.lIndex, col))) zombie.setChill?.(1)
        }
      }

      queueIce() {
        const candidates = ZombiePool.pool().filter(zombie => zombieCell(zombie) && zombie.lobberTarget?.())
        const count = this.stat('IceShroom_ProjectileSpawnCountPF')
        const damage = this.stat('ActionSplashDamagePF') * this._dmgScale
        const freeze = this.stat('IceShroom_FreezeDurationPF')
        const usedCells = new Set()
        for (let i = 0; i < count; i++) {
          const pick = Math.floor(Math.random() * candidates.length)
          const target = candidates.splice(pick, 1)[0]
          this.iceShots.push({ target, usedCells, damage, freeze, at: this.iceClock + (i + 1) * DROP_DELAY })
        }
      }
      dropPoint(shot) {
        const cells = []
        for (let row = 0; row < Square.LaneCount; row++) {
          for (let col = 0; col < Square.ColumnCount; col++) {
            const cell = Square.getLnC(row, col)
            if (cell?.isInLawn()) cells.push(cell)
          }
        }
        let cell = zombieCell(shot.target)
        if (!cell) {
          const unused = cells.filter(candidate => !shot.usedCells.has(candidate))
          const choices = unused.length ? unused : cells
          cell = choices[Math.floor(Math.random() * choices.length)]
        }
        if (!cell) return
        shot.usedCells.add(cell)
        const point = cell.plantPoint.worldPosition
        return new cc.Vec3(point.x, point.y + 20 * height() / 76, 0)
      }
      positionIcicle(node, point, time) {
        const forward = -110 + 210 * time + 25 * time ** 2
        const altitude = DROP_HEIGHT - DROP_VELOCITY * time - .5 * DROP_ACCELERATION * time ** 2
        node.setWorldPosition(point.x + forward * width() / 64,
          point.y + Math.max(0, altitude) * width() / 64, 0)
      }
      advanceShots() {
        this.iceShots = this.iceShots.filter(shot => {
          const elapsed = this.iceClock - shot.at
          if (elapsed < 0) return true
          if (!shot.node) {
            shot.point = this.dropPoint(shot)
            if (!shot.point) return false
            shot.node = draw('projectile', 'Effect', this.inLane.prjLayer, shot.point, this.playIceSound.bind(this), 0)
          }
          if (!shot.node?.isValid) return false
          this.positionIcicle(shot.node, shot.point, Math.min(elapsed, DROP_SECONDS))
          if (elapsed < DROP_SECONDS) return true
          const parent = shot.node.parent
          const end = shot.node.worldPosition.clone()
          remove(shot.node)
          draw('impact', 'Effect', parent, new cc.Vec3(end.x - 15 * width() / 64, end.y, 0), this.playIceSound.bind(this))
          const entities = [...ZombiePool.pool().filter(zombieLive), ...TombPool.pool().filter(live)]
          for (const target of nearby(end.x, end.y, 1, entities)) {
            hurt(target, shot.damage)
            target.setFreeze?.(shot.freeze)
          }
          return false
        })
      }
    })
  },

  setup(ctx) {
    ctx.plants.mutateFeatures(data => {
      if (Array.isArray(data.SANDBOX) && !data.SANDBOX.includes(CODE)) data.SANDBOX.push(CODE)
    })
    const { CardFeature, PlantIcon, plants, Square, AnimationController, UIInGame, LnC } = modules
    const card = CardFeature.prototype.cardGrouperPlant
    const icon = PlantIcon.prototype.switchPlant
    const costume = AnimationController.prototype.readCostume
    const showCard = function(...args) {
      const result = card.apply(this, args)
      if (this.PF?.CODENAME === CODE) this.ca._plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const showIcon = function(...args) {
      const result = icon.apply(this, args)
      if (plants.getPlantFeature(this.ID)?.CODENAME === CODE) this.plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const placePreview = function(...args) {
      const result = costume.apply(this, args)
      if (!this.node.name.endsWith(':display') || plants.getPlantFeature(this.ID)?.CODENAME !== CODE) return result
      const parent = this.node.parent
      if (parent === UIInGame.component?.plantInHandLayer || parent?.parent?.getComponent(LnC)?.ghostPoint === parent) {
        placeBoardArt(this, Square.SquareWidth)
      }
      return result
    }
    CardFeature.prototype.cardGrouperPlant = showCard
    PlantIcon.prototype.switchPlant = showIcon
    AnimationController.prototype.readCostume = placePreview
    ctx.runtime.onDispose(() => {
      if (CardFeature.prototype.cardGrouperPlant === showCard) CardFeature.prototype.cardGrouperPlant = card
      if (PlantIcon.prototype.switchPlant === showIcon) PlantIcon.prototype.switchPlant = icon
      if (AnimationController.prototype.readCostume === placePreview) AnimationController.prototype.readCostume = costume
    })
    ctx.controls.definePanel({
      title: '寒冰菇（国际版）',
      groups: [{ title: '普通关卡', items: [{
        key: 'unlock', type: 'action', label: '解锁寒冰菇（国际版）',
        onClick() {
          if (!ctx.plants.getFeature(CODE)) return ctx.ui.toast('请先启用寒冰菇内容包')
          const props = ctx.player.getProperty('plantProps')
          if (!props || typeof props !== 'object') return ctx.ui.toast('请先进入一个玩家存档')
          if (props[CODE]?.progress >= 1) return ctx.ui.toast('寒冰菇已解锁')
          ctx.player.setProperty('plantProps', { ...props, [CODE]: {
            medal: false, costume: -1, costumes: [], boost: 0, ...props[CODE], progress: 1, tutorialLevel: 1,
          } })
          ctx.ui.toast('寒冰菇已解锁，重新进入关卡后可选用')
        },
      }] }],
    })
  },
}


};
const create_kiwibeast = (entityService, behaviorFiles) => {
const NS = 'gzh.kiwibeast'
const CODE = 'gpn_677a682e6b69776962656173742e636f6e74656e74_6b6977696265617374'
const ART_TILE_WIDTH = 128
const BASE_ART_SCALE = .42
const STAGE_NAMES = ['One', 'Two', 'Three']
const EFFECT_NAMES = ['attack_pulse', 'pf_pulse', 'tile_hit']
const FOOD_CLIP = 'plantfood_stage3'
const RETALIATION_DAMAGE = 300
const REGEN_DELAY = 3
const REGEN_PER_SECOND = 100
const REGEN_HEALTH_LIMIT = 4000
const live = actor => actor?.node?.isValid && actor.node.activeInHierarchy && actor.isAlive()
const hostile = zombie => live(zombie) && zombie.isRealZombie !== false && !zombie.hypnotized && !zombie.potionInvisible
let engine

function fitBoardArt(control, width) {
  const placement = control.db?.armature()?.getBone('boardPlacement')
  if (!placement) return
  placement.offset.scaleX = placement.offset.scaleY = width / ART_TILE_WIDTH / BASE_ART_SCALE
  placement.invalidUpdate()
}

return {
  startup(ctx) {
    const cc = ctx.engine.getCc()
    const module = name => ctx.engine.getSystemModule(`chunks:///_virtual/${name}.ts`)
    const { ZombiePool, TombPool, ZombieDamageDetails } = module('CharacterManager')
    const { Square } = module('Square')
    const { LevelPlay } = module('levelController')
    engine = {
      Square, plants: module('Plants').plants, UIInGame: module('UI').UIInGame,
      CardFeature: module('CardFeature').CardFeature, PlantIcon: module('PlantIcon').PlantIcon,
      AnimationController: module('AnimationController').AnimationController, LnC: module('LnC').LnC,
    }
    const files = behaviorFiles
    const displays = new Set()
    const effects = new Map()
    let stats, audioMap
    const unitX = () => Square.SquareWidth / 64
    const unitY = () => Square.SquareHeight / 76

    function destroyEffect(node) {
      displays.delete(node)
      if (node?.isValid) node.destroy()
    }
    async function loadEffect(name) {
      const [skeletonJson, atlasJson, png] = await Promise.all([
        files.readText(`fx/${name}_ske.json`), files.readText(`fx/${name}_tex.json`), files.readBytes(`fx/${name}.png`),
      ])
      const image = new Image()
      const url = URL.createObjectURL(new Blob([png], { type: 'image/png' }))
      try { image.src = url; await image.decode() } finally { URL.revokeObjectURL(url) }
      const texture = new cc.Texture2D()
      texture.image = new cc.ImageAsset(image)
      const skeleton = new cc.dragonBones.DragonBonesAsset()
      const atlas = new cc.dragonBones.DragonBonesAtlasAsset()
      skeleton.dragonBonesJson = skeletonJson
      atlas.atlasJson = atlasJson
      atlas.texture = texture
      effects.set(name, { skeleton, atlas, texture })
    }
    ctx.registrations.add('kiwibeast-media', {
      async prepare() {
        const [statText, soundText] = await Promise.all([
          files.readText('stats.json'), files.readText('audio.json'), ...EFFECT_NAMES.map(loadEffect),
        ])
        stats = JSON.parse(statText)
        audioMap = JSON.parse(soundText)
      },
      publish() {},
      dispose() {
        for (const node of displays) destroyEffect(node)
        for (const { skeleton, atlas, texture } of effects.values()) {
          skeleton.destroy()
          atlas.destroy()
          texture.destroy()
        }
        effects.clear()
      },
    })

    class KiwiEffectClock extends cc.Component {
      update(delta) {
        const running = LevelPlay.gaming
        this.display.timeScale = running ? 1 : 0
        if (running) this.advance?.(delta)
      }
      onDestroy() { displays.delete(this.node) }
    }
    cc._decorator.ccclass('gzhKiwibeastEffectClock')(KiwiEffectClock)

    function draw(name, parent, point, scaleX = 1, scaleY = scaleX) {
      if (!parent?.isValid) return null
      const { skeleton, atlas } = effects.get(name)
      const node = new cc.Node(`Kiwibeast ${name}`)
      node.parent = parent
      node.layer = parent.layer
      node.setWorldPosition(point)
      node.setWorldScale(scaleX * Square.SquareWidth / ART_TILE_WIDTH, scaleY * Square.SquareWidth / ART_TILE_WIDTH, 1)
      const display = node.addComponent(cc.dragonBones.ArmatureDisplay)
      display.dragonAsset = skeleton
      display.dragonAtlasAsset = atlas
      display.armatureName = 'Body'
      display.on(cc.dragonBones.EventObject.COMPLETE, () => destroyEffect(node))
      node.addComponent(KiwiEffectClock).display = display
      displays.add(node)
      display.playAnimation('animation', 1)
      return node
    }

    function playSound(sounds, name, node) {
      if (!audioMap[name]?.length || !node?.isValid) return
      for (const { samples, probability } of audioMap[name]) {
        if (!samples.length || (probability < 1 && Math.random() >= probability)) continue
        const audio = sounds[`s${samples[Math.floor(Math.random() * samples.length)]}`]
        if (audio) (node.getComponent(cc.AudioSource) || node.addComponent(cc.AudioSource)).playOneShot(audio, 1)
      }
    }

    function targets() {
      return [...ZombiePool.pool().filter(hostile), ...TombPool.pool().filter(live)]
    }
    function gap(value, span) {
      return Math.max(0, span.x - value, value - span.y)
    }
    function groundDistance(center, target) {
      const rect = target.bodyRec
      if (!rect) return Infinity
      const x = gap(center.x, rect.prjX()) / unitX()
      const y = gap(center.y, rect.prjY()) / unitY()
      return Math.hypot(x, y)
    }
    function knockBack(plant) {
      const { mX, mY, mWidth, mHeight } = stats.properties.Actions[1].RectTriggerRange
      const center = plant.node.worldPosition
      const left = center.x + mX * unitX()
      const right = left + mWidth * unitX()
      const top = center.y - mY * unitY()
      const bottom = top - mHeight * unitY()
      for (const zombie of plant.inLane?.zombiePool() || []) {
        if (!hostile(zombie) || zombie.invincible || !zombie.knockBackable || !zombie.leapable ||
            !zombie.specialZombieLeapable() ||
            !zombie.bodyRec?.judgeCrossRecXY(left, bottom, right, top)) continue
        zombie.leapBy(new cc.Vec2(96 / 64, 0), true, .5, (150 / 7) * unitX())
      }
    }

    const framework = entityService
    framework.registerBehavior(NS, 'kiwibeast', (Base, { sounds }) => class Kiwibeast extends Base {
      characterOnLoad() {
        this.anmControl.anmCompleteListenerDone = true
        super.characterOnLoad()
      }
      specialPlantOnEnable() {
        this.kiwiStage = 1
        this.kiwiDamageTaken = 0
        this.kiwiRetaliationDamage = 0
        this.kiwiRegenTimer = REGEN_DELAY
        this.kiwiCooldown = stats.properties.Actions[0].CooldownTimeMax
        this.anmControl.RandomAnim = []
        this.anmControl.WaterAnm = ['water']
        this.anmControl.timeScaleDefault = 1
        fitBoardArt(this.anmControl, Square.SquareWidth)
        this.playKiwiIdle()
      }
      playKiwiClip(name) {
        this.kiwiClip = name
        this.anmControl.playAnimation(name, 1, 0, 1)
      }
      playKiwiIdle() {
        const base = `idle_stage${this.kiwiStage}_`
        this.anmControl.IdleAnim = base
        this.playKiwiClip(base + ['', '2', '3'][Math.floor(Math.random() * 3)])
      }
      waterable() { return !this.fooding && this.kiwiClip?.startsWith('idle_stage') }
      water() { if (live(this) && this.waterable()) this.playKiwiClip('water') }
      specialPlantOnUnsheepend() { this.playKiwiIdle() }
      heal(amount) {
        if (amount >= 0 && this.health > this.toughness) return
        super.heal(amount)
      }
      onDamaged(_damage, before, after) {
        const lost = before - after
        if (!(lost > 0)) return
        this.kiwiDamageTaken += lost
        this.kiwiRegenTimer = REGEN_DELAY
        if (this.kiwiStage !== 3 || after <= 0) return
        this.kiwiRetaliationDamage = Math.min(RETALIATION_DAMAGE, this.kiwiRetaliationDamage + lost)
      }
      regenerate(gameDelta) {
        if (this.health >= REGEN_HEALTH_LIMIT) return
        this.kiwiRegenTimer -= gameDelta
        if (this.kiwiRegenTimer > 0) return
        const ticks = 1 + Math.floor(-this.kiwiRegenTimer)
        this.kiwiRegenTimer += ticks
        this.health = Math.min(REGEN_HEALTH_LIMIT, this.health + ticks * REGEN_PER_SECOND)
      }
      radiusProfile(plantFood = false) {
        const stage = STAGE_NAMES[this.kiwiStage - 1]
        return stats.properties[plantFood ? 'PlantfoodDamageRadius' : `GrowthStage${stage}DamageRadius`]
      }
      pulseDamage(plantFood) {
        const stage = STAGE_NAMES[this.kiwiStage - 1]
        const key = plantFood ? 'KiwiBeast_PlantfoodDamage' : `KiwiBeast_GrowthStage${stage}Damage`
        return (stats.levels[key][0] + (this.MintBoosted ? stats.powerups[key][0] : 0)) * this._dmgScale
      }
      specialPlantUpdate(delta, gameDelta) {
        if (!live(this) || !LevelPlay.gaming || !(gameDelta > 0)) return
        this.kiwiCooldown -= gameDelta
        if (this.kiwiStage === 3 && !this.sheepend) this.regenerate(gameDelta)
        if (!(delta > 0) || this.fooding || this.sheepend || !this.kiwiClip?.startsWith('idle_stage')) return
        const { GrowthStageOneDamageLimit, GrowthStageTwoDamageLimit } = stats.properties
        const next = this.kiwiDamageTaken > GrowthStageTwoDamageLimit ? 3
          : this.kiwiDamageTaken > GrowthStageOneDamageLimit ? 2 : 1
        if (next > this.kiwiStage) {
          const clip = this.kiwiStage === 2 ? 'growth_stage2' : next === 3 ? 'growth_stage1_2' : 'growth_stage1'
          this.kiwiStage = next
          knockBack(this)
          this.playKiwiClip(clip)
          return
        }
        if (this.kiwiCooldown > 0) return
        const center = Square.getSquareWorldPosition(this.lIndex, this.cIndex)
        const radius = this.radiusProfile().RadiusInGridSquareWidths * 64
        if (targets().some(target => groundDistance(center, target) <= radius)) this.playKiwiClip(`attack_stage${this.kiwiStage}`)
      }
      food(showEffect) {
        const health = this.health
        const applied = super.food(showEffect)
        if (applied && health > this.health) this.health = health
        return applied
      }
      specialPlantFood() {
        this.kiwiStage = 3
        knockBack(this)
        this.playKiwiClip(FOOD_CLIP)
      }
      specialPlantFoodEnd() { if (live(this) && !this.sheepend) this.playKiwiIdle() }
      animationListener(event) {
        if (!live(this) || this.sheepend || event.animationState?.name !== this.kiwiClip) return
        if (event.name === 'PlaySample') playSound(sounds, event.data?.strings?.[0], this.node)
        if (event.name === 'KiwiClipStop') this.finishKiwiClip()
        if (event.name !== 'use_action') return
        if (this.fooding && this.kiwiClip === FOOD_CLIP) this.emitKiwiPulse(true)
        else if (this.kiwiClip.startsWith('attack_stage')) {
          this.kiwiCooldown = stats.properties.Actions[0].CooldownTimeMax
          this.emitKiwiPulse(false)
        }
      }
      animationOnComplete(event) {
        if (event.animationState?.name === this.kiwiClip) this.finishKiwiClip()
      }
      finishKiwiClip() {
        if (!live(this) || this.sheepend) return
        if (this.fooding && this.kiwiClip === FOOD_CLIP) this.foodEnd()
        else if (!this.fooding) this.playKiwiIdle()
      }
      emitKiwiPulse(plantFood) {
        const profile = this.radiusProfile(plantFood)
        const cell = Square.getSquareWorldPosition(this.lIndex, this.cIndex)
        const center = new cc.Vec3(cell.x, cell.y, this.node.worldPosition.z)
        const parent = this.inLane?.prjLayer
        const wave = draw(plantFood ? 'pf_pulse' : 'attack_pulse', parent, center, profile.PopAnimScaleX, profile.PopAnimScaleY)
        if (!wave) return
        const clock = wave.getComponent(KiwiEffectClock)
        const amount = this.pulseDamage(plantFood)
        const maxRadius = profile.RadiusInGridSquareWidths * 64
        let elapsed = 0
        clock.advance = delta => {
          elapsed += delta
          if (elapsed < profile.PulsePropagationTime) return
          clock.advance = null
          const struck = targets().filter(target => groundDistance(center, target) <= maxRadius)
          if (!plantFood && struck.length && live(this) && this.kiwiStage === 3 &&
              this.kiwiRetaliationDamage >= RETALIATION_DAMAGE) {
            this.kiwiRetaliationDamage = 0
            knockBack(this)
          }
          for (const target of struck) {
            const point = target.node.worldPosition.clone()
            if (target.shadeSocket && Number.isFinite(target.worldPositionYFoot)) {
              // This PAM is registered at the dust baseline. Use the rendered foot position.
              point.x = target.shadeSocket.worldPosition.x
              point.y = target.worldPositionYFoot + target.height_depth
            } else {
              point.y += 20 * unitY()
            }
            const impact = draw('tile_hit', target.inLane?.prjLayer || parent, point)
            playSound(sounds, profile.ImpactSound, impact)
            target.dealDamage(new ZombieDamageDetails(amount, true, false, false))
          }
        }
      }
    })
  },

  setup(ctx) {
    ctx.plants.mutateFeatures(data => {
      if (Array.isArray(data.SANDBOX) && !data.SANDBOX.includes(CODE)) data.SANDBOX.push(CODE)
    })
    const { CardFeature, PlantIcon, plants, Square, AnimationController, UIInGame, LnC } = engine
    const card = CardFeature.prototype.cardGrouperPlant
    const icon = PlantIcon.prototype.switchPlant
    const costume = AnimationController.prototype.readCostume
    const showCard = function (...args) {
      const result = card.apply(this, args)
      if (this.PF?.CODENAME === CODE) this.ca._plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const showIcon = function (...args) {
      const result = icon.apply(this, args)
      if (plants.getPlantFeature(this.ID)?.CODENAME === CODE) this.plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const placePreview = function (...args) {
      const result = costume.apply(this, args)
      if (!this.node.name.endsWith(':display') || plants.getPlantFeature(this.ID)?.CODENAME !== CODE) return result
      const parent = this.node.parent
      if (parent === UIInGame.component?.plantInHandLayer || parent?.parent?.getComponent(LnC)?.ghostPoint === parent) {
        fitBoardArt(this, Square.SquareWidth)
      }
      return result
    }
    CardFeature.prototype.cardGrouperPlant = showCard
    PlantIcon.prototype.switchPlant = showIcon
    AnimationController.prototype.readCostume = placePreview
    ctx.runtime.onDispose(() => {
      if (CardFeature.prototype.cardGrouperPlant === showCard) CardFeature.prototype.cardGrouperPlant = card
      if (PlantIcon.prototype.switchPlant === showIcon) PlantIcon.prototype.switchPlant = icon
      if (AnimationController.prototype.readCostume === placePreview) AnimationController.prototype.readCostume = costume
    })
    ctx.controls.definePanel({
      title: '野兽猕猴桃（国际版）',
      groups: [{ title: '普通关卡', items: [{
        key: 'unlock', type: 'action', label: '解锁野兽猕猴桃（国际版）',
        onClick() {
          if (!ctx.plants.getFeature(CODE)) return ctx.ui.toast('请先启用野兽猕猴桃内容包')
          const props = ctx.player.getProperty('plantProps')
          if (!props || typeof props !== 'object') return ctx.ui.toast('请先进入一个玩家存档')
          if (props[CODE]?.progress >= 1) return ctx.ui.toast('野兽猕猴桃已解锁')
          ctx.player.setProperty('plantProps', { ...props, [CODE]: {
            medal: false, costume: -1, costumes: [], boost: 0, ...props[CODE], progress: 1, tutorialLevel: 1,
          } })
          ctx.ui.toast('野兽猕猴桃已解锁，重新进入关卡后可选用')
        },
      }] }],
    })
  },
}

};
const create_tigergrass = (entityService, behaviorFiles) => {
const NS = 'gzh.tigergrass'
const CONTENT = NS + '.content'
const codename = id => 'gpn_' + [CONTENT, id].map(value =>
  Array.from(new TextEncoder().encode(value), byte => byte.toString(16).padStart(2, '0')).join('')
).join('_')
const CODE = codename('tigergrass')
const TIGER_CODE = codename('grass-tiger')
const ART_TILE_WIDTH = 128
const BASE_ART_SCALE = .42
const MAX_NATURAL_STAGE = 2
const PLANT_FOOD_STAGE = 3
const EFFECT_NAMES = ['jump', 'back', 'die', 'hit']
const live = actor => actor?.node?.isValid && actor.node.activeInHierarchy && actor.isAlive()
const hostile = actor => !actor.hypnotized && !actor.potionInvisible
let engine

function fitBoardArt(control, width) {
  const placement = control.db?.armature()?.getBone('boardPlacement')
  if (!placement) return
  const ratio = width / ART_TILE_WIDTH / BASE_ART_SCALE
  placement.offset.scaleX = placement.offset.scaleY = ratio
  // Use the lawn pivot (198, 210) relative to the shared art pivot (188, 242).
  placement.offset.x = -10 * ratio
  placement.offset.y = -32 * ratio
  placement.invalidUpdate()
}

return {
  startup(ctx) {
    const cc = ctx.engine.getCc()
    const module = name => ctx.engine.getSystemModule('chunks:///_virtual/' + name + '.ts')
    const { ZombieDamageDetails, Rectangle, ZombiePool, TombPool } = module('CharacterManager')
    const { Zombie } = module('Zombie')
    const { zombies } = module('Zombies')
    const { Square } = module('Square')
    const { LevelPlay } = module('levelController')
    const { NodePools } = module('NodePools')
    engine = {
      Square, plants: module('Plants').plants, UIInGame: module('UI').UIInGame,
      CardFeature: module('CardFeature').CardFeature, PlantIcon: module('PlantIcon').PlantIcon,
      AnimationController: module('AnimationController').AnimationController, LnC: module('LnC').LnC,
    }

    const files = behaviorFiles
    const displays = new Set()
    const effects = new Map()
    let stats, audioMap, flightShadowFrame, groundShadowFrame
    const unitX = () => Square.SquareWidth / 64
    const unitY = () => Square.SquareHeight / 76
    const artScale = () => Square.SquareWidth / ART_TILE_WIDTH
    const stat = key => stats.levels[key][0]
    const tigerStat = key => stat('TigerGrass_' + key)
    const growth = stage => tigerStat('GlobalGrowthMultiplier') ** (stage - 1)

    function destroyEffect(node) {
      displays.delete(node)
      if (node?.isValid) node.destroy()
    }

    async function loadTexture(path) {
      const png = await files.readBytes(path)
      const image = new Image()
      const url = URL.createObjectURL(new Blob([png], { type: 'image/png' }))
      try {
        image.src = url
        await image.decode()
      } finally {
        URL.revokeObjectURL(url)
      }
      const texture = new cc.Texture2D()
      texture.image = new cc.ImageAsset(image)
      return texture
    }

    async function loadShadow(path, columns) {
      const texture = await loadTexture(path)
      const frame = new cc.SpriteFrame()
      frame.texture = texture
      frame.rect = new cc.Rect(0, 0, texture.width / columns, texture.height)
      frame.originalSize = new cc.Size(texture.width / columns, texture.height)
      return frame
    }

    function addShadow(parent, name, frame) {
      const node = new cc.Node('Tiger Grass ' + name + ' shadow')
      node.parent = parent
      node.layer = parent.layer
      node.setSiblingIndex(0)
      const sprite = node.addComponent(cc.Sprite)
      sprite.spriteFrame = frame
      sprite.sizeMode = cc.Sprite.SizeMode.RAW
      return node
    }

    async function loadEffect(name) {
      const [skeletonJson, atlasJson, texture] = await Promise.all([
        files.readText('fx/' + name + '_ske.json'), files.readText('fx/' + name + '_tex.json'),
        loadTexture('fx/' + name + '.png'),
      ])
      const skeleton = new cc.dragonBones.DragonBonesAsset()
      const atlas = new cc.dragonBones.DragonBonesAtlasAsset()
      skeleton.dragonBonesJson = skeletonJson
      atlas.atlasJson = atlasJson
      atlas.texture = texture
      effects.set(name, { skeleton, atlas, texture })
    }

    ctx.registrations.add('tigergrass-media', {
      async prepare() {
        const [statText, soundText] = await Promise.all([
          files.readText('stats.json'), files.readText('audio.json'),
          loadShadow('fx/projectile-shadow.png', 2).then(frame => { flightShadowFrame = frame }),
          loadShadow('fx/ground-shadow.png', 1).then(frame => { groundShadowFrame = frame }),
          ...EFFECT_NAMES.map(loadEffect),
        ])
        stats = JSON.parse(statText)
        audioMap = JSON.parse(soundText)
      },
      publish() {},
      dispose() {
        for (const node of displays) destroyEffect(node)
        for (const { skeleton, atlas, texture } of effects.values()) {
          skeleton.destroy()
          atlas.destroy()
          texture.destroy()
        }
        effects.clear()
        for (const frame of [flightShadowFrame, groundShadowFrame]) {
          frame?.texture.destroy()
          frame?.destroy()
        }
      },
    })

    class TigerEffectClock extends cc.Component {
      update(delta) {
        this.display.timeScale = LevelPlay.gaming ? 1 : 0
        if (LevelPlay.gaming) this.advance?.(delta)
      }
      onDestroy() { displays.delete(this.node) }
    }
    cc._decorator.ccclass('gzhTigerGrassEffectClock')(TigerEffectClock)

    function sound(sounds, name, node) {
      const samples = audioMap[name]
      if (!samples?.length || !node?.isValid) return
      const audio = sounds['s' + samples[Math.floor(Math.random() * samples.length)]]
      if (audio) (node.getComponent(cc.AudioSource) || node.addComponent(cc.AudioSource)).playOneShot(audio, 1)
    }

    function faceRight(node) {
      const parent = node.parent.worldMatrix
      node.setScale(artScale() / parent.m00, artScale() / parent.m05, 1)
    }

    function draw(name, clip, lane, point, sounds) {
      const parent = lane?.prjLayer
      if (!parent?.isValid) return null
      const { skeleton, atlas } = effects.get(name)
      const node = new cc.Node('Tiger Grass ' + name)
      node.parent = parent
      node.layer = parent.layer
      node.setWorldPosition(point)
      faceRight(node)
      const display = node.addComponent(cc.dragonBones.ArmatureDisplay)
      display.dragonAsset = skeleton
      display.dragonAtlasAsset = atlas
      display.armatureName = 'Body'
      display.on(cc.dragonBones.EventObject.FRAME_EVENT, event => {
        if (event.name === 'PlaySample') sound(sounds, event.data?.strings?.[0], node)
      })
      node.addComponent(TigerEffectClock).display = display
      displays.add(node)
      display.playAnimation(clip, 1)
      if (name === 'hit' || name === 'die') {
        display.on(cc.dragonBones.EventObject.COMPLETE, () => destroyEffect(node))
      }
      return node
    }

    function travel(node, from, to, startZ, endZ, lob, projectile, finish) {
      const duration = lob.TimeOfFlight * (1 + lob.TimeOfFlightVariance * Math.random())
      const height = lob.LobHeight * (1 + lob.LobHeightVariance * Math.random())
      const acceleration = (Math.max(startZ, endZ) - height) / (duration * .5 - duration ** 2 * .125)
      const velocity = (endZ - startZ) / duration - acceleration * duration * .5
      let elapsed = 0
      const clock = node.getComponent(TigerEffectClock)
      const shadow = projectile.HasShadow ? addShadow(node, 'flight', flightShadowFrame) : null
      const place = (x, y, z) => {
        node.setWorldPosition(x, y + z * unitY(), from.z)
        if (!shadow) return
        const scale = z <= 200 ? 1 : Math.max(0, (800 - z) / 600)
        shadow.active = scale > .01
        shadow.setWorldPosition(x + (projectile.ShadowOffset?.x || 0) * unitX(),
          y - (projectile.ShadowOffset?.y || 0) * unitY(), from.z)
        shadow.setScale(scale, scale, 1)
      }
      place(from.x, from.y, startZ)
      clock.advance = delta => {
        elapsed = Math.min(elapsed + delta, duration)
        const t = elapsed / duration
        const z = startZ + (velocity + acceleration * elapsed * .5) * elapsed
        place(
          from.x + (to.x - from.x) * t,
          from.y + (to.y - from.y) * t,
          z,
        )
        if (t === 1) {
          clock.advance = null
          destroyEffect(node)
          finish()
        }
      }
    }

    function select(lane, left, right, allowTombs = true) {
      const pick = actors => {
        let target, edge = Infinity
        for (const actor of actors) {
          if (!live(actor) || actor instanceof Zombie && !hostile(actor)) continue
          const rect = actor.bodyRec?.prjX()
          if (!rect || !Number.isFinite(rect.x) || rect.y < left || rect.x > right || rect.x >= edge) continue
          edge = rect.x
          target = actor
        }
        return target
      }
      return pick(lane?.zombiePool() || []) || (allowTombs ? pick(lane?.tombPool() || []) : null)
    }

    function impact(target, lane, sounds, projectile = null) {
      const point = new cc.Vec3(target.worldPositionX, target.worldPositionY, target.node.worldPosition.z)
      const offset = projectile?.ImpactOffset
      const x = offset?.[0].Min ?? stats.tiger.SwipeImpactEffectOffset.x
      const y = offset ? offset[1].Min + Math.random() * (offset[1].Max - offset[1].Min)
        : stats.tiger.SwipeImpactEffectOffset.y
      if (!projectile?.ImpactShowsAtZombieFeet) point.y += target.height_depth ?? 0
      point.x += x * unitX()
      point.y -= y * unitY()
      const fx = draw('hit', 'animation', lane, point, sounds)
      if (projectile) sound(sounds, projectile.ImpactSoundEvent, fx)
    }

    const framework = entityService
    framework.registerBehavior(NS, 'tiger', (Base, { sounds }) => class GrassTiger extends Base {
      specialZombieOnEnable() {
        this.db.node.active = true
        this.useShade = false
        this.bindsToLane = false
        this.isRealZombie = false
        this.isBrainEater = false
        this.coloredWhenHypnotized = false
        this.canBeKilledByRule = false
        this.havePlantfood = false
        this.haveSun = 0
        this.groanSound = []
        this.tigerRun = null
        this.tigerSwing = null
        this.tigerClock = 0
        this.tigerWait = 0
        this.tigerNextSwipe = 0
      }
      specialZombieOnDisable() { this.removeGroundShadow() }
      removeGroundShadow() {
        if (!this.tigerShadow) return
        this.tigerShadow.active = false
        destroyEffect(this.tigerShadow)
        this.tigerShadow = null
      }
      placeGroundShadow() {
        const { ShadowOffset: offset, ShadowScaling: scale } = stats.tiger
        const matrix = this.node.worldMatrix
        this.tigerShadow.setWorldPosition(this.worldPositionX + offset.x * unitX(),
          this.worldPositionY - offset.y * unitY(), this.node.worldPosition.z)
        this.tigerShadow.setScale(scale.x * offset.z * artScale() / matrix.m00,
          scale.y * offset.z * artScale() / matrix.m05, 1)
      }
      get toughness() { return this.tigerRun?.maximumHealth ?? super.toughness }
      get HitRect() {
        const { mX, mY, mWidth, mHeight } = stats.tiger.HitRect
        return { x: mX * unitX(), y: (mY + mHeight / 2) * unitY(), w: mWidth * unitX(), h: mHeight * unitY() }
      }
      defaultSetBodyRec() {
        const { x, y, w, h } = this.HitRect
        this.bodyRec = Rectangle.createRectangleCenter(
          new cc.Vec2(this.worldPositionX + x, this.worldPositionY + y), w, h,
        )
      }
      detectPlant() {}
      CanBeLockedByBlueBerry() { return false }
      playWalk() { this.playIdle() }
      playIdle() {
        if (this.tigerRun) return
        this.isWalking = false
        this.isEating = false
        this.isIdling = true
        this.setSpeed(0, false)
      }
      startTiger(run, point) {
        this.tigerRun = run
        this.worldPositionVec3 = point
        this.judgeInLnC()
        this.hypnotized = true
        this.worldPositionVec3 = point
        this.bodyRecHiddenCD = 0
        this.setBodyRec()
        this.health = run.health
        faceRight(this.db.node)
        this.tigerShadow = addShadow(this.node, 'ground', groundShadowFrame)
        displays.add(this.tigerShadow)
        this.placeGroundShadow()
        this.db.armature().animation.gotoAndStopByFrame('lvl' + run.stage + '_tiger_attack', 0)
        if (this.swipeTargets().length) this.swing()
      }
      swipeTargets() {
        const { mX, mY, mWidth, mHeight } = stats.tiger.AttackRect
        const left = this.worldPositionX + (mX - mWidth / 2) * unitX()
        const right = left + mWidth * unitX()
        const bottom = this.worldPositionY + this.height_depth - mY * unitY()
        const top = bottom + mHeight * unitY()
        const firstRow = Square.judgeLIndex(top)
        const lastRow = Square.judgeLIndex(bottom)
        return [...ZombiePool.pool(), ...TombPool.pool()].filter(target => {
          const row = target.inLane?.LaneIndex
          const rect = target.bodyRec
          if (!live(target) || !hostile(target) || !rect || row == null || row < firstRow || row > lastRow) return false
          const x = rect.prjX()
          const y = rect.prjY()
          return x.x < right && x.y > left && y.x < top && y.y > bottom
        })
      }
      swing() {
        this.tigerWait = 0
        this.tigerNextSwipe = this.tigerClock + stats.tiger.SwipeAttackRate
        this.tigerSwing = 'lvl' + this.tigerRun.stage + '_tiger_attack'
        this.db.playAnimation(this.tigerSwing, 1)
      }
      animationListener(event) {
        super.animationListener(event)
        if (!live(this) || !this.tigerRun || event.animationState?.name !== this.tigerSwing) return
        if (event.name === 'PlaySample') sound(sounds, event.data?.strings?.[0], this.node)
        if (event.name === 'TigerStop') this.tigerSwing = null
        if (event.name !== 'swipe') return
        for (const target of this.swipeTargets()) {
          impact(target, target.inLane ?? this.inLane, sounds)
          target.dealDamage(new ZombieDamageDetails(this.tigerRun.damage, true, false, false))
        }
      }
      specialZombieUpdate(delta) {
        if (!live(this) || !this.tigerRun || !LevelPlay.gaming || !(delta > 0)) return
        this.tigerClock += delta
        faceRight(this.db.node)
        this.placeGroundShadow()
        if (this.swipeTargets().length) {
          this.tigerWait = 0
          if (!this.tigerSwing && this.tigerClock >= this.tigerNextSwipe) this.swing()
        } else {
          this.tigerWait += delta
          if (this.tigerWait >= stats.tiger.TigerWaitTime) this.returnTiger()
        }
      }
      returnTiger() {
        const run = this.tigerRun
        if (!live(this) || !run) return
        const owner = run.owner
        const lane = this.inLane
        if (!live(owner) || owner.tigerRun !== run) {
          this.retireTiger()
          return
        }
        const offset = stats.tiger.TigerSpawnOffset
        const from = new cc.Vec3(this.worldPositionX + offset.x * unitX(),
          this.worldPositionY + this.height_depth - offset.y * unitY(), this.node.worldPosition.z)
        // The native return aims 62 units down from the top of the owner's 76-unit row.
        const tile = owner.inLnC
        const to = new cc.Vec3(tile.node.worldPosition.x, tile.node.worldPosition.y - 24 * unitY(), from.z)
        // The native return projectile uses the unmirrored pose while moving left.
        const node = draw('back', 'lvl' + run.stage + '_tiger_back', lane, from, sounds)
        const health = this.health
        run.actor = null
        run.flight = node
        this.retireTiger()
        if (node) travel(node, from, to, 0, 0, stats.tiger.TigerLaunchProps, stats.projectiles[1].objdata,
          () => owner.tigerBack(run, health))
        else owner.tigerBack(run, health)
      }
      retireTiger() {
        this.tigerRun = null
        this.removeGroundShadow()
        this.playDie(true, null, false, undefined, false, false, false)
        NodePools.destroyPooly(this.node)
      }
      playSpecialZombieDieForced() {
        const run = this.tigerRun
        if (!run) return
        this.tigerRun = null
        this.removeGroundShadow()
        const point = new cc.Vec3(this.worldPositionX, this.worldPositionY, this.node.worldPosition.z)
        const lane = this.inLane
        this.db.node.active = false
        draw('die', 'die', lane, point, sounds)
        run.owner.tigerLost(run)
        queueMicrotask(() => {
          if (this.node.isValid && this.node.activeInHierarchy && this.dead) NodePools.destroyPooly(this.node)
        })
      }
    })

    framework.registerBehavior(NS, 'tigergrass', (Base, { sounds }) => class TigerGrass extends Base {
      characterOnLoad() {
        this.anmControl.anmCompleteListenerDone = true
        super.characterOnLoad()
      }
      specialPlantOnEnable() {
        this.tigerStage = 1
        this.tigerAge = 0
        this.tigerHealth = tigerStat('TigerHealth')
        this.tigerRegen = 0
        this.tigerRun = null
        this.tigerFoodUsed = false
        this.anmControl.RandomAnim = []
        this.anmControl.WaterAnm = ['water']
        this.anmControl.timeScaleDefault = 1
        fitBoardArt(this.anmControl, Square.SquareWidth)
        this.tigerIdle()
      }
      playTiger(name) {
        this.tigerClip = name
        this.anmControl.playAnimation(name, 1, 0, 1)
      }
      get summonStage() {
        return this.tigerFoodUsed ? PLANT_FOOD_STAGE : this.tigerStage
      }
      get maximumTigerHealth() {
        return this.tigerFoodUsed ? tigerStat('TigerPFHealth') : tigerStat('TigerHealth') * growth(this.tigerStage)
      }
      tigerIdle() {
        const clip = 'lvl' + this.summonStage + '_idle'
        this.anmControl.IdleAnim = clip
        const healing = this.tigerHealth < this.maximumTigerHealth
        this.playTiger(this.tigerRun ? 'lvl' + this.tigerRun.stage + '_attack_loop'
          : this.tigerRegen > 0 ? 'idle' : healing ? 'heal' : clip)
      }
      waterable() { return !this.fooding && !this.tigerRun && this.tigerClip?.endsWith('_idle') }
      water() { if (live(this) && this.waterable()) this.playTiger('water') }
      specialPlantOnUnsheepend() { this.tigerIdle() }
      specialPlantUpdate(delta, gameDelta) {
        if (!live(this) || !LevelPlay.gaming || !(gameDelta > 0)) return
        const growing = !this.tigerFoodUsed && this.tigerStage < MAX_NATURAL_STAGE
        if (growing) this.tigerAge += gameDelta
        if (this.sheepend || this.tigerRun || !(delta > 0)) return
        if (this.tigerRegen > 0) {
          this.tigerRegen -= gameDelta
          if (this.tigerRegen > 0) return
          this.tigerHealth = this.maximumTigerHealth
          this.tigerIdle()
        }
        if (!(this.tigerClip?.endsWith('_idle') || this.tigerClip === 'heal')) return
        this.tigerHealth = Math.min(this.maximumTigerHealth,
          this.tigerHealth + tigerStat('TigerHealing') * growth(this.summonStage) * gameDelta)
        if (growing && this.tigerAge >= tigerStat('GrowthTime')) {
          this.tigerStage++
          this.tigerAge -= tigerStat('GrowthTime')
          this.tigerHealth = this.maximumTigerHealth
          this.tigerIdle()
        }
        if (this.findPounceTarget()) this.playTiger('lvl' + this.summonStage + '_attack_start')
        else if (this.tigerClip === 'heal' && this.tigerHealth >= this.maximumTigerHealth) this.tigerIdle()
      }
      findPounceTarget() {
        const range = stats.properties.Actions[1].RectTriggerRange
        const x = this.node.worldPosition.x + range.mX * Square.SquareWidth
        return select(this.inLane, x, x + range.mWidth * Square.SquareWidth)
      }
      get foodable() { return !this.tigerFoodUsed && super.foodable }
      set foodable(value) { super.foodable = value }
      specialPlantFood() {
        this.tigerFoodUsed = true
        const previous = this.tigerRun
        this.tigerRun = null
        if (live(previous?.actor)) previous.actor.retireTiger()
        if (previous?.flight?.isValid) destroyEffect(previous.flight)
        this.tigerRegen = 0
        this.tigerHealth = this.maximumTigerHealth
        if (this.findPounceTarget()) this.playTiger('lvl3_attack_start')
        else {
          this.foodEnd()
          this.tigerIdle()
        }
      }
      specialPlantFoodEnd() {
        if (live(this) && !this.sheepend && this.tigerClip === 'lvl3_attack_start') this.tigerIdle()
      }
      animationListener(event) {
        if (!live(this) || this.sheepend || event.animationState?.name !== this.tigerClip) return
        if (event.name === 'PlaySample') sound(sounds, event.data?.strings?.[0], this.node)
        if (event.name === 'use_action' && this.tigerClip.endsWith('_attack_start')) this.pounce()
        if (event.name === 'TigerStop') this.finishTigerClip()
      }
      animationOnComplete(event) {
        if (event.animationState?.name === this.tigerClip && !this.tigerClip?.endsWith('_idle')) this.finishTigerClip()
      }
      finishTigerClip() {
        if (!live(this) || this.sheepend) return
        const finishFood = this.tigerClip.endsWith('_attack_start') && this.fooding
        this.tigerIdle()
        if (finishFood) this.foodEnd()
      }
      pounce() {
        const target = this.findPounceTarget()
        if (!target || this.tigerRun) return
        const plantFood = this.tigerFoodUsed
        const key = plantFood ? 'Tigergrass_TigerPFAttackDamage' : 'Tigergrass_TigerAttackDamage'
        const damage = (stat(key) + (this.MintBoosted ? stats.powerups[key][0] : 0)) *
          (plantFood ? 1 : growth(this.tigerStage)) * this._dmgScale
        const lane = this.inLane
        const run = { owner: this, stage: this.summonStage, damage, plantFood,
          health: this.tigerHealth, maximumHealth: this.maximumTigerHealth }
        this.tigerRun = run
        const offset = stats.properties.Actions[0].SpawnOffset
        // The native launch projects the negative art Y offset onto positive height.
        const from = this.node.worldPosition.clone().add3f(offset.x * unitX(), 0, 0)
        const hitX = target.bodyRec.prjX()
        const hitY = target.bodyRec.prjY()
        const centerX = (hitX.x + hitX.y) / 2
        const ownerX = this.node.worldPosition.x
        const to = new cc.Vec3(centerX < ownerX ? ownerX + 32 * unitX() : centerX,
          target.worldPositionY, from.z)
        const targetHeight = (hitY.y - (hitY.y - hitY.x) / 3 - to.y) / unitY()
        const flight = run.flight = draw('jump', 'lvl' + run.stage + '_tiger', lane, from, sounds)
        if (!flight) {
          this.tigerRun = null
          return
        }
        const lob = stats.properties.NormalLaunchProps
        const projectile = stats.projectiles[0].objdata
        travel(flight, from, to, -offset.y, targetHeight, lob, projectile, () => {
          if (this.tigerRun !== run || !live(this)) return
          run.flight = null
          const tracked = live(target) && hostile(target)
          const landed = tracked ? target : select(lane, to.x, to.x)
          const landingLane = tracked ? target.inLane ?? lane : lane
          const point = tracked ? new cc.Vec3(target.worldPositionX, target.worldPositionY, target.height_depth ?? 0)
            : new cc.Vec3(to.x, to.y, targetHeight * unitY())
          if (landed) {
            impact(landed, landingLane, sounds, projectile)
            landed.dealDamage(new ZombieDamageDetails(damage * tigerStat('PounceDamageMultiplier'), true, false, false))
          }
          this.spawnTiger(run, landingLane, point).catch(error => {
            this.tigerLost(run)
            console.error('Tiger Grass could not spawn its tiger', error)
          })
        })
      }
      async spawnTiger(run, lane, point) {
        const { z, prop, filled_type: type } = zombies.getZombieEnumWithPropByZombieTypes(TIGER_CODE)
        const actor = await zombies.getZombieCompByID(z, false, null, prop, type)
        if (this.tigerRun !== run || !live(this)) {
          NodePools.destroyPooly(actor.node)
          return
        }
        actor.node.parent = lane.zombieLayer
        actor.spawnLane = lane
        run.actor = actor
        actor.startTiger(run, point)
      }
      tigerBack(run, health) {
        if (!live(this) || this.tigerRun !== run) return
        this.tigerRun = null
        this.tigerHealth = Math.min(health, this.maximumTigerHealth)
        this.playTiger('lvl' + run.stage + '_attack_end')
      }
      tigerLost(run) {
        if (!live(this) || this.tigerRun !== run) return
        this.tigerRun = null
        this.tigerHealth = 0
        this.tigerRegen = tigerStat('TigerRegenTime')
        if (this.fooding) this.foodEnd()
        this.tigerIdle()
      }
      specialPlantDie() {
        const run = this.tigerRun
        this.tigerRun = null
        if (run?.flight?.isValid) destroyEffect(run.flight)
        if (live(run?.actor)) run.actor.retireTiger()
      }
    })
  },

  setup(ctx) {
    ctx.plants.mutateFeatures(data => {
      if (Array.isArray(data.SANDBOX) && !data.SANDBOX.includes(CODE)) data.SANDBOX.push(CODE)
    })
    const { CardFeature, PlantIcon, plants, Square, AnimationController, UIInGame, LnC } = engine
    const card = CardFeature.prototype.cardGrouperPlant
    const icon = PlantIcon.prototype.switchPlant
    const costume = AnimationController.prototype.readCostume
    const showCard = function (...args) {
      const result = card.apply(this, args)
      if (this.PF?.CODENAME === CODE) this.ca._plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const showIcon = function (...args) {
      const result = icon.apply(this, args)
      if (plants.getPlantFeature(this.ID)?.CODENAME === CODE) this.plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const placePreview = function (...args) {
      const result = costume.apply(this, args)
      if (!this.node.name.endsWith(':display') || plants.getPlantFeature(this.ID)?.CODENAME !== CODE) return result
      const parent = this.node.parent
      if (parent === UIInGame.component?.plantInHandLayer || parent?.parent?.getComponent(LnC)?.ghostPoint === parent) {
        fitBoardArt(this, Square.SquareWidth)
      }
      return result
    }
    CardFeature.prototype.cardGrouperPlant = showCard
    PlantIcon.prototype.switchPlant = showIcon
    AnimationController.prototype.readCostume = placePreview
    ctx.runtime.onDispose(() => {
      if (CardFeature.prototype.cardGrouperPlant === showCard) CardFeature.prototype.cardGrouperPlant = card
      if (PlantIcon.prototype.switchPlant === showIcon) PlantIcon.prototype.switchPlant = icon
      if (AnimationController.prototype.readCostume === placePreview) AnimationController.prototype.readCostume = costume
    })
    ctx.controls.definePanel({
      title: '虎草（国际版）',
      groups: [{ title: '普通关卡', items: [{
        key: 'unlock', type: 'action', label: '解锁虎草（国际版）',
        onClick() {
          if (!ctx.plants.getFeature(CODE)) return ctx.ui.toast('请先启用虎草内容包')
          const props = ctx.player.getProperty('plantProps')
          if (!props || typeof props !== 'object') return ctx.ui.toast('请先进入一个玩家存档')
          if (props[CODE]?.progress >= 1) return ctx.ui.toast('虎草已解锁')
          ctx.player.setProperty('plantProps', { ...props, [CODE]: {
            medal: false, costume: -1, costumes: [], boost: 0, ...props[CODE], progress: 1, tutorialLevel: 1,
          } })
          ctx.ui.toast('虎草已解锁，重新进入关卡后可选用')
        },
      }] }],
    })
  },
}


};
const create_ultomato = (entityService, behaviorFiles) => {
const NS = 'gzh.ultomato'
const CODE = 'gpn_677a682e756c746f6d61746f2e636f6e74656e74_756c746f6d61746f'
const ORIGINAL_TILE_WIDTH = 128
const ENGINE_PLANT_SCALE = .42
const MAX_STAGE = 3
const BEAM_SECONDS = 29 / 30
const STAGE_PRICE_STEP = 50
const EFFECTS = ['hit', 'beam', 'beam_start', 'transition']
const BEAM_ORIGINS = [[-69, -118], [-70, -182], [-52, -222]]
const BEAM_IMPACTS = [[-120, -102], [-120, -166], [-120, -200]]
const BEAM_SHAFT_OFFSETS = [[3, 6], [0, -11], [15, 0]]
const BEAM_HEIGHTS = [.6, 1, 1.5]
const CAP_HEIGHTS = [1, 1.5, 2]
const live = entity => entity?.node?.isValid && entity.node.activeInHierarchy && entity.isAlive()
let engine

function fitBoardArt(control, width) {
  const placement = control.db?.armature()?.getBone('boardPlacement')
  if (!placement) return
  placement.offset.scaleX = placement.offset.scaleY = width / ORIGINAL_TILE_WIDTH / ENGINE_PLANT_SCALE
  placement.invalidUpdate()
}

return {
  startup(ctx) {
    const cc = ctx.engine.getCc()
    const module = name => ctx.engine.getSystemModule(`chunks:///_virtual/${name}.ts`)
    const { PlantPool, ZombiePool, TombPool, ZombieDamageDetails, ZombieDamageType } = module('CharacterManager')
    const { plants } = module('Plants')
    const { Square } = module('Square')
    const { LevelPlay } = module('levelController')
    const { UIInGame } = module('UI')
    const { Cards } = module('Cards')
    engine = {
      plants, Square, UIInGame, LevelPlay,
      SunCount: module('SunCount').SunCount, SandBoxLevelSettingWindow: module('SandBoxLevelSettingWindow').SandBoxLevelSettingWindow,
      CardFeature: module('CardFeature').CardFeature, PlantIcon: module('PlantIcon').PlantIcon,
      AnimationController: module('AnimationController').AnimationController,
      LnC: module('LnC').LnC,
    }
    const files = behaviorFiles
    const displays = new Set()
    const effects = new Map()
    let stats, audioMap
    const artScale = () => Square.SquareWidth / ORIGINAL_TILE_WIDTH
    const refreshCost = () => {
      for (const card of Cards.component?.CFs || []) {
        if (card?.PF?.CODENAME === CODE) card.SUNCOST = card.SUNCOST
      }
    }
    const boardPriceBonus = () => {
      let highest = 1
      for (const plant of PlantPool.cm?.plantPool || []) {
        if (plant.ultomatoStage > highest && live(plant)) highest = plant.ultomatoStage
        if (highest === MAX_STAGE) break
      }
      return STAGE_PRICE_STEP * (highest - 1)
    }
    engine.boardPriceBonus = boardPriceBonus
    const { LevelTaskCountModeEnum } = module('LevelTaskCount')
    function destroyEffect(node) {
      displays.delete(node)
      if (node?.isValid) node.destroy()
    }

    async function loadEffect(name) {
      const [skeletonText, atlasText, png] = await Promise.all([
        files.readText(`fx/${name}_ske.json`), files.readText(`fx/${name}_tex.json`), files.readBytes(`fx/${name}.png`),
      ])
      const url = URL.createObjectURL(new Blob([png], { type: 'image/png' }))
      const image = new Image()
      try { image.src = url; await image.decode() } finally { URL.revokeObjectURL(url) }
      const texture = new cc.Texture2D()
      texture.image = new cc.ImageAsset(image)
      const skeleton = new cc.dragonBones.DragonBonesAsset()
      const atlas = new cc.dragonBones.DragonBonesAtlasAsset()
      skeleton.dragonBonesJson = skeletonText
      atlas.atlasJson = atlasText
      atlas.texture = texture
      effects.set(name, { skeleton, atlas, texture })
    }
    ctx.registrations.add('ultomato-media', {
      async prepare() {
        const [statsText, audioText] = await Promise.all([
          files.readText('stats.json'), files.readText('audio.json'), ...EFFECTS.map(loadEffect),
        ])
        stats = JSON.parse(statsText)
        audioMap = JSON.parse(audioText)
      },
      publish() {},
      dispose() {
        for (const node of displays) destroyEffect(node)
        for (const { skeleton, atlas, texture } of effects.values()) {
          skeleton.destroy()
          atlas.destroy()
          texture.destroy()
        }
        effects.clear()
      },
    })

    function draw(name, clip, parent, { keep = false, onEvent, onComplete } = {}) {
      const { skeleton, atlas } = effects.get(name)
      const node = new cc.Node(`Ultomato ${name}`)
      displays.add(node)
      node.parent = parent
      node.layer = parent.layer
      node.setScale(artScale(), artScale(), 1)
      const display = node.addComponent(cc.dragonBones.ArmatureDisplay)
      display.dragonAsset = skeleton
      display.dragonAtlasAsset = atlas
      display.armatureName = 'Body'
      if (onEvent) display.on(cc.dragonBones.EventObject.FRAME_EVENT, event => onEvent(event, node))
      if (!keep) display.on(cc.dragonBones.EventObject.COMPLETE, () => {
        onComplete?.(node)
        destroyEffect(node)
      })
      display.playAnimation(clip, 1)
      return node
    }

    const zombieLive = zombie => live(zombie) && zombie.isRealZombie !== false && !zombie.hypnotized && !zombie.potionInvisible
    const hurt = (target, amount, type) => target.dealDamage(
      new ZombieDamageDetails(amount, true, false, false, null, type),
    )

    entityService.registerBehavior(NS, 'ultomato', (Base, { sounds }) => class Ultomato extends Base {
      characterOnLoad() {
        // This plant advances its own phases, including the sustained beam pose.
        this.anmControl.anmCompleteListenerDone = true
        super.characterOnLoad()
      }
      specialPlantOnEnable() {
        this.ultomatoStage = 1
        this.ultomatoPaid = this.SUNCOST + boardPriceBonus()
        this.ultomatoCooldown = stats.properties.Actions[0].InitialMinCooldownTime
        this.ultomatoBeam = null
        this.ultomatoTransition = null
        this.anmControl.RandomAnim = []
        this.anmControl.WaterAnm = ['water']
        this.anmControl.timeScaleDefault = 1
        fitBoardArt(this.anmControl, Square.SquareWidth)
        this.playUltomatoIdle()
        refreshCost()
      }
      specialPlantOnDisable() { this.clearUltomatoEffects() }
      specialPlantDie() {
        this.clearUltomatoEffects()
        refreshCost()
      }
      specialPlantOnSheepend() {
        this.clearUltomatoEffects()
        this.playUltomatoIdle()
      }
      clearUltomatoEffects() {
        this.stopUltomatoBeam()
        destroyEffect(this.ultomatoTransition)
        this.ultomatoTransition = null
        this.setUltomatoVisible(true)
      }

      setUltomatoVisible(visible) {
        const display = this.anmControl?.db
        if (display?.isValid) display.enabled = visible
      }

      plantCount() { return this.ultomatoStage || 1 }
      get suncost() { return this.ultomatoPaid ?? this.SUNCOST }
      replantableListensFirstAid() { return false }
      replantable() {
        if (!live(this) || this.ultomatoStage >= MAX_STAGE || this.fooding || this.sheepend ||
            this.leapTween || this.inLnC?.iceblock || this.inLnC?.octopus) return false
        const limit = UIInGame.component?.getLevelTaskStartingObject(LevelTaskCountModeEnum.PlantCountLimit)
        return !limit || PlantPool.getPlantAmount() < limit.MaximumPlants
      }
      replant() {
        if (!this.replantable()) return
        this.ultomatoPaid += this.SUNCOST + boardPriceBonus()
        this.ultomatoStage++
        plants.registerPlant(this.ID, 1)
        plants.registerPlantByType(this.Plant_Type_Data, 1)
        this.toughness = stats.levels[`Ultomato_HitpointsUpgrade${this.ultomatoStage}`][0]
        this.health = Math.max(this.health, this.toughness)
        this.ultomatoCooldown = stats.properties.ResetLaunchTimeOnUpgrade
        this.stopUltomatoBeam()
        this.playUltomatoIdle()
        this.playUltomatoTransition()
        this.plantInLnC.readIndex()
        refreshCost()
      }

      playUltomatoTransition(onAction, onComplete) {
        destroyEffect(this.ultomatoTransition)
        this.ultomatoTransition = draw('transition', 'animation', this.inLane.prjLayer, {
          onEvent: (event, node) => {
            if (node !== this.ultomatoTransition || !live(this)) return
            this.playUltomatoSoundEvent(event, node)
            if (event.name === 'use_action') onAction?.()
          },
          onComplete: node => {
            if (node !== this.ultomatoTransition) return
            this.ultomatoTransition = null
            onComplete?.()
          },
        })
        this.ultomatoTransition.setWorldPosition(this.node.worldPosition)
      }
      playUltomatoClip(name) {
        this.ultomatoClip = name
        this.anmControl.playAnimation(name, 1, 0, 1)
      }
      playUltomatoIdle() {
        const stage = this.plantCount()
        const variants = stage === 3 ? 3 : 2
        const idle = Math.random() < 10 / (9 + variants) ? 1 : 2 + Math.floor(Math.random() * (variants - 1))
        this.anmControl.IdleAnim = `idle${stage}_1`
        this.playUltomatoClip(`idle${stage}_${idle}`)
      }
      waterable() { return !this.fooding && this.ultomatoClip?.startsWith('idle') }
      water() { if (!this.dead && this.waterable()) this.playUltomatoClip('water') }
      playUltomatoSoundEvent(event, node = this.node) {
        if (event.name !== 'PlaySample') return
        const name = event.data?.strings?.[0]
        const options = audioMap[name]
        if (!options?.length || !node?.isValid) return
        const source = node.getComponent(cc.AudioSource) || node.addComponent(cc.AudioSource)
        const first = sounds['s' + options[0]]
        if (first) source.playOneShot(first, 1)
        const second = sounds['s' + options[1]]
        if (second && /^Play_Plant_Ultomato_Attack_0[123]$/.test(name)) {
          const stage = this.ultomatoStage
          this.scheduleOnce(() => {
            if (source.isValid && live(this) && this.ultomatoStage === stage &&
                this.ultomatoClip.startsWith(`attack${stage}_`)) source.playOneShot(second, .5)
          }, .35)
        }
      }
      animationListener(event) {
        if (!live(this) || event.animationState?.name !== this.ultomatoClip) return
        this.playUltomatoSoundEvent(event)
        if (this.fooding && this.ultomatoClip === 'plantfood' && event.name === 'use_action') this.ultomatoFoodPulse()
        if (!this.fooding && event.name === 'UltomatoAttackStop') this.advanceUltomatoAttack(this.ultomatoClip)
      }
      animationOnComplete(event) {
        const clip = this.ultomatoClip
        if (!live(this) || event.animationState?.name !== clip) return
        if (this.fooding) {
          if (clip === 'plantfood') {
            this.ultomatoFoodPulse()
            this.setUltomatoVisible(false)
            this.playUltomatoClip(`idle${this.ultomatoStage}_1`)
            this.playUltomatoTransition(
              () => this.setUltomatoVisible(true),
              () => { if (this.fooding && live(this)) this.foodEnd() },
            )
          }
          return
        }
        if (clip.startsWith('attack')) this.advanceUltomatoAttack(clip)
        else this.playUltomatoIdle()
      }
      advanceUltomatoAttack(clip) {
        const attack = `attack${this.ultomatoStage}`
        if (clip === `${attack}_start`) {
          const target = this.beamTarget()
          if (target) {
            this.ultomatoCooldown += 2
            this.playUltomatoClip(`${attack}_loop`)
            this.startUltomatoBeam(target)
          } else {
            this.playUltomatoClip(`${attack}_end`)
          }
        } else if (clip === `${attack}_loop`) {
          this.playUltomatoClip(`${attack}_end`)
        } else {
          this.playUltomatoIdle()
        }
      }

      beamTarget() {
        const start = this.worldPositionX
        const end = Square.getSquareWorldPosition(this.lIndex, Square.MaxColumnIndex).x + Square.SquareWidth / 2
        const ahead = target => {
          const span = (target.bodyRecForShooter || target.bodyRec)?.prjX()
          return span && span.y > start && span.x <= end
        }
        const zombies = this.inLane.zombiePool().filter(target => zombieLive(target) && ahead(target))
        const targets = zombies.length ? zombies : this.inLane.tombPool().filter(target => live(target) && ahead(target))
        return targets.reduce((first, target) => !first || target.worldPositionX < first.worldPositionX ? target : first, null)
      }
      startUltomatoBeam(target) {
        const clip = `animation${this.ultomatoStage}`
        const parent = this.inLane.prjLayer
        this.ultomatoBeamLeft = BEAM_SECONDS
        this.ultomatoBeam = {
          beam: draw('beam', clip, parent, { keep: true }),
          start: draw('beam_start', clip, parent, { keep: true }),
          hit: draw('hit', clip, parent, { keep: true }),
        }
        this.updateUltomatoBeam(0, 1, target)
      }
      stopUltomatoBeam() {
        if (!this.ultomatoBeam) return
        for (const node of Object.values(this.ultomatoBeam)) destroyEffect(node)
        this.ultomatoBeam = null
      }
      updateUltomatoBeam(delta, speed, target = this.beamTarget()) {
        const { start, beam, hit } = this.ultomatoBeam
        const scale = artScale()
        const nativeScale = 2 * scale
        const stage = this.ultomatoStage - 1
        const capHeight = CAP_HEIGHTS[stage]
        const [originX, originY] = BEAM_ORIGINS[stage]
        const [hitX, hitY] = BEAM_IMPACTS[stage]
        const [shaftX, shaftY] = BEAM_SHAFT_OFFSETS[stage]
        const { BeamStartOffset, BeamStartArtOffset, BeamEndArtOffset } = stats.properties
        const point = this.node.worldPosition
        const span = (target?.bodyRecForShooter || target?.bodyRec)?.prjX()
        if (span) this.ultomatoBeamEndX = (span.x + span.y) / 2
        const end = this.ultomatoBeamEndX
        const beamX = point.x + (BeamStartOffset.mX + shaftX) * nativeScale
        const beamY = point.y - (BeamStartOffset.mY + shaftY) * nativeScale
        const authorLength = 2 * Math.hypot(BeamEndArtOffset.mX - BeamStartArtOffset.mX,
          BeamEndArtOffset.mY - BeamStartArtOffset.mY)
        start.setWorldPosition(point.x + originX * nativeScale, point.y - originY * nativeScale, point.z)
        start.setWorldScale(scale, scale * capHeight, 1)
        beam.setWorldPosition(beamX, beamY, point.z)
        beam.setWorldScale(Math.hypot(end - beamX, point.y - beamY) / authorLength,
          scale * BEAM_HEIGHTS[stage], 1)
        hit.setWorldPosition(end + hitX * nativeScale, point.y - hitY * nativeScale, point.z)
        hit.setWorldScale(scale, scale * capHeight, 1)
        for (const node of [start, beam, hit]) {
          const display = node.getComponent(cc.dragonBones.ArmatureDisplay)
          display.timeScale = speed
        }
        if (target && delta > 0) {
          const key = `Ultomato_BeamDPSUpgrade${this.ultomatoStage}`
          const dps = stats.levels[key][0] + (this.MintBoosted ? stats.powerups[key][0] : 0)
          // The ray channel uses Gardendless's fire-ash death without thawing live targets.
          hurt(target, dps * delta * this._dmgScale, ZombieDamageType.ray)
        }
      }
      specialPlantUpdate(delta, gameDelta, speed) {
        if (!live(this) || this.sheepend || this.fooding || !this.ultomatoClip) return
        if (this.ultomatoBeam) {
          this.updateUltomatoBeam(Math.min(delta, this.ultomatoBeamLeft), speed)
          this.ultomatoBeamLeft -= delta
          if (this.ultomatoBeamLeft <= 0) {
            this.stopUltomatoBeam()
          }
        }
        if (!(gameDelta > 0) || this.stunned > 0) return
        this.ultomatoCooldown -= delta
        if (delta > 0 && this.ultomatoCooldown <= 0 && this.ultomatoClip.startsWith('idle') && this.beamTarget()) {
          const { CooldownTimeMin, CooldownTimeMax } = stats.properties.Actions[0]
          this.ultomatoCooldown = CooldownTimeMin + (CooldownTimeMax - CooldownTimeMin) * Math.random()
          this.playUltomatoClip(`attack${this.ultomatoStage}_start`)
        }
      }

      specialPlantFood() {
        this.clearUltomatoEffects()
        this.ultomatoFoodApplied = false
        this.playUltomatoClip('plantfood')
      }
      ultomatoFoodPulse() {
        if (this.ultomatoFoodApplied) return
        this.ultomatoFoodApplied = true
        this.explodeUltomato()
      }
      specialPlantFoodEnd() {
        destroyEffect(this.ultomatoTransition)
        this.ultomatoTransition = null
        this.setUltomatoVisible(true)
        if (live(this)) this.playUltomatoIdle()
      }
      explodeUltomato() {
        const { ExplodeRadius } = stats.properties.Actions[1]
        const amount = (stats.levels.ActionDamagePF[0] + (this.MintBoosted ? stats.powerups.ActionDamagePF[0] : 0)) * this._dmgScale
        const left = Square.getSquareWorldPosition(this.lIndex, 0).x - Square.SquareWidth / 2
        const right = left + Square.ColumnCount * Square.SquareWidth
        const unitX = 64 / Square.SquareWidth
        const unitY = 76 / Square.SquareHeight
        const centerX = this.worldPositionX
        const centerY = this.worldPositionY + 30 / unitY
        for (const target of [...ZombiePool.pool().filter(zombieLive), ...TombPool.pool().filter(live)]) {
          const rect = target.bodyRecForShooter || target.bodyRec
          const x = rect?.prjX()
          const y = rect?.prjY()
          if (!x || !y || x.y < left || x.x > right || Math.abs(target.lIndex - this.lIndex) > ExplodeRadius) continue
          const dx = Math.max(x.x - centerX, centerX - x.y, 0) * unitX
          const dy = Math.max(y.x - centerY, centerY - y.y, 0) * unitY
          if (dx ** 2 + dy ** 2 <= (64 * ExplodeRadius) ** 2) {
            hurt(target, amount, ZombieDamageType.physicle)
          }
        }
      }
    })
  },

  setup(ctx) {
    ctx.plants.mutateFeatures(data => {
      if (Array.isArray(data.SANDBOX) && !data.SANDBOX.includes(CODE)) data.SANDBOX.push(CODE)
    })
    const { plants, Square, UIInGame, LevelPlay, SunCount, SandBoxLevelSettingWindow, boardPriceBonus,
      CardFeature, PlantIcon, AnimationController, LnC } = engine
    const cost = Object.getOwnPropertyDescriptor(CardFeature.prototype, 'SUNCOST')
    const getCost = function() {
      const base = cost.get.call(this)
      if (this.PF?.CODENAME !== CODE || !UIInGame.component?.node?.active || LevelPlay.isBeghouled) return base
      return base + boardPriceBonus()
    }
    Object.defineProperty(CardFeature.prototype, 'SUNCOST', { ...cost, get: getCost })

    const card = CardFeature.prototype.cardGrouperPlant
    const icon = PlantIcon.prototype.switchPlant
    const costume = AnimationController.prototype.readCostume
    const place = LnC.prototype.PlaceUIPlant
    const showCard = function(...args) {
      const result = card.apply(this, args)
      if (this.PF?.CODENAME === CODE) this.ca._plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const showIcon = function(...args) {
      const result = icon.apply(this, args)
      if (plants.getPlantFeature(this.ID)?.CODENAME === CODE) this.plantDB.playAnimation('SeedPacket', 1)
      return result
    }
    const placePreview = function(...args) {
      const result = costume.apply(this, args)
      if (!this.node.name.endsWith(':display') || plants.getPlantFeature(this.ID)?.CODENAME !== CODE) return result
      const parent = this.node.parent
      if (parent === UIInGame.component?.plantInHandLayer || parent?.parent?.getComponent(LnC)?.ghostPoint === parent) {
        fitBoardArt(this, Square.SquareWidth)
      }
      return result
    }
    const placeUltomato = function(...args) {
      const ui = this.UIInGame
      const current = ui?.currentCF
      if (current?.PF?.CODENAME === CODE && ui.index >= 0 && ui.index <= 7 && !SandBoxLevelSettingWindow.freePlant) {
        const price = current.SUNCOST
        if (SunCount.Value < price) return SunCount.component?.playWarn()
        ui.willCostSun = price
      }
      return place.apply(this, args)
    }
    CardFeature.prototype.cardGrouperPlant = showCard
    PlantIcon.prototype.switchPlant = showIcon
    AnimationController.prototype.readCostume = placePreview
    LnC.prototype.PlaceUIPlant = placeUltomato
    ctx.runtime.onDispose(() => {
      if (Object.getOwnPropertyDescriptor(CardFeature.prototype, 'SUNCOST').get === getCost) {
        Object.defineProperty(CardFeature.prototype, 'SUNCOST', cost)
      }
      if (CardFeature.prototype.cardGrouperPlant === showCard) CardFeature.prototype.cardGrouperPlant = card
      if (PlantIcon.prototype.switchPlant === showIcon) PlantIcon.prototype.switchPlant = icon
      if (AnimationController.prototype.readCostume === placePreview) AnimationController.prototype.readCostume = costume
      if (LnC.prototype.PlaceUIPlant === placeUltomato) LnC.prototype.PlaceUIPlant = place
    })
    ctx.controls.definePanel({
      title: '终极番茄（国际版）',
      groups: [{ title: '普通关卡', items: [{
        key: 'unlock', type: 'action', label: '解锁终极番茄（国际版）',
        onClick() {
          if (!ctx.plants.getFeature(CODE)) return ctx.ui.toast('请先启用终极番茄内容包')
          const props = ctx.player.getProperty('plantProps')
          if (!props || typeof props !== 'object') return ctx.ui.toast('请先进入一个玩家存档')
          if (props[CODE]?.progress >= 1) return ctx.ui.toast('终极番茄已解锁')
          ctx.player.setProperty('plantProps', { ...props, [CODE]: {
            medal: false, costume: -1, costumes: [], boost: 0, ...props[CODE], progress: 1, tutorialLevel: 1,
          } })
          ctx.ui.toast('终极番茄已解锁，重新进入关卡后可选用')
        },
      }] }],
    })
  },
}

};

const factories = [create_headbutter, create_iceshroom, create_kiwibeast, create_tigergrass, create_ultomato];
let behaviors;
export default {
  async startup(ctx) {
    let framework;
    await entityFramework.startup({
      ...ctx,
      registry: {
        provide(id, service) {
          if (id !== "entities") throw new Error(`Unexpected framework service: ${id}`);
          framework = service;
        },
      },
    });
    if (!framework) throw new Error("Entity framework did not register");
    const reader = ctx.files.own();
    behaviors = factories.map((create, index) => create(
      framework,
      filesUnder(reader, `plants/${plants[index]}/behavior/`),
    ));
    for (const behavior of behaviors) await behavior.startup(ctx);
  },

  async setup(ctx) {
    const groups = [];
    const cleanup = [];
    ctx.runtime.onDispose(() => {
      for (const dispose of cleanup.reverse()) dispose();
    });
    for (const [index, behavior] of behaviors.entries()) {
      await behavior.setup({
        plants: ctx.plants,
        player: ctx.player,
        ui: ctx.ui,
        runtime: { onDispose: dispose => cleanup.push(dispose) },
        controls: {
          definePanel(panel) {
            groups.push(...panel.groups.map(group => ({
              ...group,
              title: panel.title,
              items: group.items.map(item => ({ ...item, key: `${plants[index]}.${item.key}` })),
            })));
          },
        },
      });
    }
    ctx.controls.definePanel({ title: "国际版植物合集", groups });
  },
};
